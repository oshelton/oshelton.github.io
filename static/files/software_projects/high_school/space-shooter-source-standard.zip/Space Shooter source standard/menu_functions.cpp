#include <allegro.h>
#include <stdio.h>
#include <pmask.h>
#include "graphics.h"
#include "funct_defs.h"

#define START 0
#define HELP  1
#define OPTIONS 2
#define EXIT 3
#define BACK 4
#define WINDOWED 5
#define FULLSCREEN 6


int choice;
int choice_delay = 0;
int menu;

int cursor_x;
int cursor_y;
int cursor_rot;
int g_mode = WINDOW;

BITMAP *title_image = NULL;
BITMAP *options_image = NULL; 
BITMAP *cursor = NULL;

void set_menu_graphics()
{
 title_image = (BITMAP*) graphics[title].dat;
 options_image = (BITMAP*) graphics[options_background].dat;
 cursor = (BITMAP*) graphics[menu_cursor].dat;
}

void set_menu_vars()
{
 menu = MAIN_MENU;
 choice = START;
 choice_delay=0;
}

void input_menu()
{
 if (key[KEY_DOWN] && choice==START && choice_delay>=20) 
 {
  choice = HELP;
  choice_delay = 0;
 }
 else if (key[KEY_DOWN] && choice==HELP && choice_delay>=20) 
 {
  choice = OPTIONS;
  choice_delay = 0;
 }
 else if (key[KEY_DOWN] && choice==OPTIONS && choice_delay>=20) 
 {
  choice = EXIT;
  choice_delay = 0;
 }
 else if (key[KEY_DOWN] && choice==EXIT && choice_delay>=20) 
 {
  choice = START;
  choice_delay = 0;
 }
 
 
 if (key[KEY_UP] && choice==START && choice_delay>=20) 
 {
  choice = EXIT;
  choice_delay = 0;
 }
 else if (key[KEY_UP] && choice==EXIT && choice_delay>=20) 
 {
  choice = OPTIONS;
  choice_delay = 0;
 }
 else if (key[KEY_UP] && choice ==OPTIONS && choice_delay>=20) 
 {
  choice = HELP;
  choice_delay = 0;
 }
 else if (key[KEY_UP] && choice ==HELP && choice_delay>=20) 
 {
  choice = START;
  choice_delay = 0;
 }
 
 
 if (key[KEY_ENTER] && choice == START) mode = GAME;
 if (key[KEY_ENTER] && choice == EXIT) game_on=FALSE;
 if (key[KEY_ENTER] && choice == OPTIONS) 
 {
  menu=OPTIONS_MENU;
  choice = BACK;
 } 
 
 if (menu == MAIN_MENU)
 {
  if (cursor_x>=7 && cursor_x<=220 && cursor_y >=17 && cursor_y <=63)
  {
   choice = START;
   if (mouse_b & 1) mode = GAME;
  }
 
  if (cursor_x>=7 && cursor_x<=100 && cursor_y >=70 && cursor_y <=116)
  {
   choice = HELP;
  }
 
  if (cursor_x>=7 && cursor_x<=155 && cursor_y >=127 && cursor_y <=174)
  { 
   choice = OPTIONS;
   if (mouse_b & 1) 
   {
    menu=OPTIONS_MENU;
    choice = BACK;
   }  
  }  
 
  if (cursor_x>=7 && cursor_x<=90 && cursor_y >=179 && cursor_y <=225)
  {
   choice = EXIT;
   if (mouse_b & 1) game_on=FALSE;  
  }
}

else if (menu== OPTIONS_MENU)
  {
   if (cursor_x>=200 && cursor_x<=440 && cursor_y>=125 && cursor_y<=145) 
   {
    choice= WINDOWED;
    if (mouse_b & 1 && !g_mode==WINDOW) 
    {
     g_mode = WINDOW;
     set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0);
    }
   }
   
   if (cursor_x>=160 && cursor_x<=420 && cursor_y>=150 && cursor_y<=170)
   {
    choice = FULLSCREEN;
    if (mouse_b & 1 && !g_mode==FULL ) 
    {
     g_mode=FULL;
     set_gfx_mode(GFX_AUTODETECT, 640, 480, 0, 0);
    }
   } 
   
   if (cursor_x>=230 && cursor_x<=360 && cursor_y>=410 && cursor_y<=451)
   {
    choice = BACK;
    if (mouse_b & 1) 
    {
     menu=MAIN_MENU;
     choice = START;
    }
   } 
}
 
 if (key[KEY_ESC] && choice_delay>=80) game_on=FALSE;
}

void logic_menu()
{
 
 cursor_x = mouse_x;
 cursor_y = mouse_y;
 cursor_rot+=2;
 choice_delay++;
}

void draw_menu()
{
 if (menu==MAIN_MENU) blit(title_image, buffer,0,0,0,0,640,480);
 else if(menu == OPTIONS_MENU) blit(options_image, buffer,0,0,0,0,640,480);
 
 if (choice ==START) rect(buffer, 7,17,220,63, makecol(200,200,255)); 
 else if (choice ==HELP) rect(buffer, 7,70,100,116, makecol(200,200,255));
 else if (choice ==OPTIONS) rect(buffer, 7,127,155,174, makecol(200,200,255));
 else if (choice ==EXIT) rect(buffer, 7,179,90,225, makecol(200,200,255));
 else if (choice ==BACK) rect(buffer, 255,412,390,454, makecol(200,200,255));
 else if (choice ==WINDOWED) rect(buffer, 200,140,440,160, makecol(200,200,255));
 else if (choice ==FULLSCREEN) rect(buffer, 190,162,450,183, makecol(200,200,255));
 
 rotate_sprite(buffer, cursor, cursor_x,cursor_y, itofix(cursor_rot));
 
 blit(buffer, screen, 0,0,0,0,640,480);
 clear_bitmap(buffer);
}   
