#include <math.h>
#include <iostream>

#define pi 3.14156

using namespace std;

int main()
{
 float cos_value = cos(90);//*pi/180;
 float sin_value = sin(90);//*pi/180;
 
 cout<< "Cosine of 90 is "<<cos_value<< " and the sin is "<<sin_value;
 cin.get();
}
