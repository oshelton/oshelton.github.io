/* Allegro datafile object indexes, produced by grabber v4.2.0 (beta4), MinGW32.s */
/* Datafile: c:\Documents and Settings\Big O\My Documents\My programs\Tank Chaser\sounds.dat */
/* Date: Fri Sep 30 16:52:06 2005 */
/* Do not hand edit! */

#define d_bad_choice                     0        /* SAMP */
#define d_select                         1        /* SAMP */

