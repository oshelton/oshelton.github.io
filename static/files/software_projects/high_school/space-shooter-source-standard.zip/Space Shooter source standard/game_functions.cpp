#include <allegro.h>
#include <stdio.h>
#include <pmask.h>
#include "graphics.h"
#include "characters.h"
#include "funct_defs.h"

#define DEAD 0
#define ALIVE 1

#define ON 100
#define OFF 101

#define STRAIGHT 10
#define LEFT     11
#define RIGHT    12

void enemy_basic_anim();
void player1_anim();

powerup speedinc;  //delares the 1st power up structure.
                   //strangely enough, it won't work if placed within the main function
powerup healthinc;
powerup powerinc;     

character enemies[30];
projectile enemygun;
projectile enemygun_2;


character player1;

projectile playergun_1;
projectile playergun_2; 
projectile playergun_3;
projectile playergun_4;



float star_scroll=0;
float star_scroll_2=-480;

int health_width;
int gun_width;
int speed_width;

int wave;

int i_rand;
int i_rand_2;

int power_level = 1;
int score = 0;
int lives = 2;
char score_string[16] = "0";
char lives_string[16] = "3";

int speed = 3;

int i=1;  //repeater for the enemy index. mucho importante, do not touch!

int frame_counter=0;

DATAFILE *graphics = NULL;

struct PMASK *enemybasic_mask, *bullet_mask, *enemy_bullet_mask, *player_mask, *powerup_mask;  //declares the masks used in pixel-perfect collision
    
BITMAP *myship = NULL;
BITMAP *myship_left = NULL;
BITMAP *myship_right = NULL;
BITMAP *good_gun = NULL;
BITMAP *bad_gun = NULL;
BITMAP *enemy_basic;

RLE_SPRITE *shockwave_a;
RLE_SPRITE *shockwave_b;
RLE_SPRITE *shockwave_c;
RLE_SPRITE *shockwave_d;
RLE_SPRITE *shockwave_e;
RLE_SPRITE *shockwave_f;
RLE_SPRITE *shockwave_g;
RLE_SPRITE *shockwave_h;
RLE_SPRITE *shockwave_i;

BITMAP *speed_up = NULL;
BITMAP *health_up = NULL;
BITMAP *power_up = NULL;

BITMAP *stars = NULL;
BITMAP *stars2 = NULL;
BITMAP *buffer = NULL; // Declare a BITMAP called buffer.

void set_graphics()
{
 graphics = load_datafile("graphics.dat");
 
 buffer = create_bitmap(640,480); //Create an empty bitmap.

 if (graphics == NULL)
    {
       set_gfx_mode(GFX_TEXT,0,0,0,0);
       allegro_message("Could not load datafile, make sure the datafile is in the same folder as the .exe!");
       exit(EXIT_FAILURE);
    }
    
 if (buffer==NULL){
         set_gfx_mode(GFX_TEXT,0,0,0,0);
         allegro_message("Could not create buffer!");
         exit(EXIT_FAILURE);                     
         }

 stars = (BITMAP*) graphics[stars_1].dat;
 stars2 = (BITMAP*) graphics[stars_1].dat;

 
  enemy_basic = (BITMAP*) graphics[first_enemy].dat;
  shockwave_a = (RLE_SPRITE*) graphics[shockwave_1].dat;
  shockwave_b = (RLE_SPRITE*) graphics[shockwave_2].dat;
  shockwave_c = (RLE_SPRITE*) graphics[shockwave_3].dat;
  shockwave_d = (RLE_SPRITE*) graphics[shockwave_4].dat;
  shockwave_e = (RLE_SPRITE*) graphics[shockwave_5].dat;
  shockwave_f = (RLE_SPRITE*) graphics[shockwave_6].dat;
  shockwave_g = (RLE_SPRITE*) graphics[shockwave_7].dat;
  shockwave_h = (RLE_SPRITE*) graphics[shockwave_8].dat;
  shockwave_i = (RLE_SPRITE*) graphics[shockwave_9].dat;
  i++;
 

 myship = (BITMAP*) graphics[my_ship].dat;
 myship_left = (BITMAP*) graphics[my_ship_left].dat;
 myship_right = (BITMAP*) graphics[my_ship_right].dat;
 good_gun = (BITMAP*) graphics[player_gun].dat;
 bad_gun = (BITMAP*) graphics[enemybullet].dat;
 speed_up = (BITMAP*) graphics[speedup].dat;
 health_up = (BITMAP*) graphics[healthup].dat;
 power_up = (BITMAP*) graphics[gunup].dat;	

 bullet_mask = create_allegro_pmask(good_gun);
 enemy_bullet_mask = create_allegro_pmask(bad_gun);
 player_mask = create_allegro_pmask(myship);
 powerup_mask = create_allegro_pmask(speed_up);
 enemybasic_mask= create_allegro_pmask(enemy_basic);    	
}

void starting_vars()
{
  cos_table();
  sin_table();
  
  score=0;
  power_level=1;
  player1.loc_x = 300;
  player1.loc_y = 400;
  player1.health = 5;
  player1.state = ALIVE;
  player1.explode_timer=0;
  player1.direction = STRAIGHT;

  playergun_1.loc_x = -222;
  playergun_1.loc_y = -222;

  playergun_2.loc_x = -222;
  playergun_2.loc_y = -222;

  playergun_3.loc_x = -222;
  playergun_3.loc_y = -222;

  playergun_4.loc_x = -222;
  playergun_4.loc_y = -222;

  speedinc.loc_x = -100;
  speedinc.loc_y = -300;
  speedinc.spawn_timer = rand()%1000 + 1000;

  healthinc.loc_x = -200;
  healthinc.loc_y = -500;
  healthinc.spawn_timer = rand()%1300 + 1000;

  powerinc.loc_x = -120;
  powerinc.loc_y = -400;
  powerinc.spawn_timer = rand()%1100 + 1000;

  enemygun.loc_x = -50;
  enemygun.loc_y = 500; 
  
  enemygun_2.loc_x =-50; 
  enemygun_2.loc_y =500;

  while (i<=30)
  {
   enemies[i].loc_x = rand()%620 +20;
   enemies[i].loc_y = rand()%1900-1900;
   enemies[i].speed = 1;
   enemies[i].state = ALIVE;
   enemies[i].explode_timer=0;
   i++;        
  }
  if (i > 30) i=1; //must be set to 1 in order for in game while loops to work.  
                 //i=0 would be the same as Matrix at x=0.  It would cause the program to crash.   
}   

void input_game()
{
 if (key[KEY_LEFT] && player1.loc_x > 0 ){
    player1.loc_x-= speed;
    player1.direction = LEFT;
 }
 
else if ( !key[KEY_LEFT] || !key[KEY_RIGHT]) player1.direction = STRAIGHT;   
          
 if (key[KEY_RIGHT] && player1.loc_x < 615 ){
    player1.loc_x+= speed;
    player1.direction = RIGHT;
 }
  
 
          
 if (key[KEY_UP] && player1.loc_y>0 ){
    player1.loc_y-= speed;  //the y axis is flipped.  Bitmaps are read and drawn from bottom up.
 }                       //even though there origin is at the top-left.  
          
 if (key[KEY_DOWN] && player1.loc_y<450 ){
    player1.loc_y+= speed;
 }
 
 if (key[KEY_P]) system("PAUSE");
 
 if (key[KEY_Q]) 
 {
  starting_vars();
  mode=MENU;
 }
          
 if (key[KEY_SPACE])
    {
    if (power_level ==1 && playergun_1.loc_y<=0)
       {
        playergun_1.loc_x = player1.loc_x+10;
        playergun_1.loc_y = player1.loc_y;
       }
    
    else if (power_level ==2)
       {
       if (playergun_1.loc_y<=0)
          {
           playergun_1.loc_x = player1.loc_x+17;
           playergun_1.loc_y = player1.loc_y;
          }
       if (playergun_2.loc_y <=0)
          {
           playergun_2.loc_x = player1.loc_x+1;
           playergun_2.loc_y = player1.loc_y;
          }
       }
           
    else if (power_level ==3)
       {
       if (playergun_1.loc_y<=0)
          {
           playergun_1.loc_x = player1.loc_x+10;
           playergun_1.loc_y = player1.loc_y-1;
          }
       if (playergun_3.loc_y<=0)
          {
           playergun_3.loc_x = player1.loc_x+1;
           playergun_3.loc_y = player1.loc_y;
          }
       if (playergun_4.loc_y<=0)
          {
           playergun_4.loc_x = player1.loc_x+17;
           playergun_4.loc_y = player1.loc_y;
          }
       }
       
       
       //clear_keybuf();
    }    
}

void logic_game()
{
 if (i>30) i=1;  //restores the index to 1.
 
 playergun_1.loc_y-=6;  //move the player's bullet up 6 every cycle.
 playergun_2.loc_y-=6;
          
 playergun_3.loc_y-=sin_values[110]*6;
 playergun_3.loc_x+=cos_values[110]*2;
          
 playergun_4.loc_y-=sin_values[70]*6;
 playergun_4.loc_x+= cos_values[70]*2;
          
 speedinc.loc_y+=1;
 healthinc.loc_y+=1;
 powerinc.loc_y+=1;
          
 star_scroll+=.5;
 star_scroll_2+=.5;
 
 enemygun.loc_y+= 3;
 enemygun_2.loc_y+=3;
  
 
          
 while (i<=30) //draws the basic enemies & their bullets.
 {
  enemies[i].loc_y+= enemies[i].speed;                       
  i++;             
 }
 if (i>30) i=1;
          
 //statement for enemy firing
          
 i_rand = rand()%29+1;        
 i = i_rand;     
 if (enemies[i].loc_y>=0 && enemies[i].loc_y<=300 && enemygun.loc_y>=480 && !enemies[i].state == DEAD)
 {
  enemygun.loc_x = enemies[i].loc_x+8;
  enemygun.loc_y = enemies[i].loc_y+15;
 }
 
 i_rand = rand()%29+1;
 i = i_rand;
 if (enemies[i].loc_y>=0 && enemies[i].loc_y<=300 && enemygun_2.loc_y>=480 && !enemies[i].state == DEAD)
 {
  enemygun_2.loc_x = enemies[i].loc_x+8;
  enemygun_2.loc_y = enemies[i].loc_y+15;
 }
 
 i=1;
          
  if (star_scroll >= 480){
  star_scroll = -480;
   }
  
  if (star_scroll_2 >= 480){
  star_scroll_2 = -480;
  }
  
  //routines for checking for collision between the basic enemies and the player bullets.
  
  while (i<=30)
  {                      
   if (check_pmask_collision(enemybasic_mask, bullet_mask, enemies[i].loc_x, enemies[i].loc_y, playergun_1.loc_x, playergun_1.loc_y)  && enemies[i].state ==ALIVE)
   {
    playergun_1.loc_x = -500;
    playergun_1.loc_y = -1;
    enemies[i].state = DEAD;
    
    if (enemies[i].loc_y<= player1.loc_y-100) score+=2;
    else score+= 3;            

   }
   
  if (check_pmask_collision(enemybasic_mask, bullet_mask, enemies[i].loc_x, enemies[i].loc_y, playergun_2.loc_x, playergun_2.loc_y)  && enemies[i].state ==ALIVE)
   {
    //enemies[i].loc_x = -50;
    playergun_2.loc_x = -500;
    playergun_2.loc_y = -1;
    enemies[i].state = DEAD;
    
    if (enemies[i].loc_y<= player1.loc_y-100) score+=2;
    else score+= 3;                        
   } 
   
   if (check_pmask_collision(player_mask, enemy_bullet_mask, player1.loc_x, player1.loc_y, enemygun.loc_x, enemygun.loc_y) && player1.state==ALIVE)
   {
    enemygun.loc_x = -50;
    player1.health -=1;
    
    player1.shield = ON;
    player1.shield_timer = 0;
   }
   
   if (check_pmask_collision(player_mask, enemy_bullet_mask, player1.loc_x, player1.loc_y, enemygun_2.loc_x, enemygun_2.loc_y))
   {
    enemygun_2.loc_x = -100;
    player1.health -=1;
    
    player1.shield = ON;
    player1.shield_timer = 0;
   }
   
   if (check_pmask_collision(enemybasic_mask, bullet_mask, enemies[i].loc_x, enemies[i].loc_y, playergun_3.loc_x, playergun_3.loc_y))
   {            
    playergun_3.loc_x = -500;
    playergun_3.loc_y = -1;
    enemies[i].state = DEAD;
    
    if (enemies[i].loc_y<= player1.loc_y-100) score+=2;
    else score+= 3;
   }
   
   if (check_pmask_collision(enemybasic_mask, bullet_mask, enemies[i].loc_x, enemies[i].loc_y, playergun_4.loc_x, playergun_4.loc_y))
   {
    playergun_4.loc_x = -500;
    playergun_4.loc_y = -1;
    enemies[i].state = DEAD;
    
    if (enemies[i].loc_y<= player1.loc_y-100) score+=2;
    else score+= 3;
   }
   if (check_pmask_collision(enemybasic_mask, player_mask, enemies[i].loc_x , enemies[i].loc_y, player1.loc_x, player1.loc_y) && enemies[i].state ==ALIVE && player1.state==ALIVE)
   {              
      enemies[i].state = DEAD;
      player1.health -=1;
      
      player1.shield = ON;
      player1.shield_timer = 0;
   }
   i++; 
  } 
  
  if (i>30) i=1;  //restores the index to 1.               
  
  while (i<=30)
  {
   if (enemies[i].state == DEAD) 
     {
      enemies[i].explode_timer++;
      if (enemies[i].explode_timer ==9) 
      {
       enemies[i].loc_x = -50;
       enemies[i].explode_timer=0;
       enemies[i].state = ALIVE;
      }
     }
   i++;
  } 
  if (i>30) i=1; 
  //begins routine for checking collision with speed_up powerup
  if (check_pmask_collision(powerup_mask, player_mask, speedinc.loc_x, speedinc.loc_y, player1.loc_x, player1.loc_y) && player1.state==ALIVE ) 
  {
     if (speed<=5) speed+=1;
     else score+=5;
     speedinc.loc_x = -200;
     speedinc.loc_y = -200;
  }
  //health powerup
  if (check_pmask_collision(powerup_mask, player_mask, healthinc.loc_x, healthinc.loc_y, player1.loc_x, player1.loc_y) && player1.state==ALIVE) 
  {
     if (player1.health<5) player1.health+=1;
     else score+=5;
     healthinc.loc_x = -200;
     healthinc.loc_y = -200;
  }
  //power power up
  if (check_pmask_collision(powerup_mask, player_mask, powerinc.loc_x, powerinc.loc_y, player1.loc_x, player1.loc_y) && player1.state==ALIVE) 
  {
     if (power_level==1) power_level+=1;
     else if(power_level ==2) power_level+=1;
     else score+=5;
     powerinc.loc_x = -200;
     powerinc.loc_y = -200;
  }
  
  
  //power up spawn statemnts
  if (frame_counter == speedinc.spawn_timer)
  {
     speedinc.loc_x = rand()%620 ;
     speedinc.loc_y = -500;
  }
  
  if (frame_counter == healthinc.spawn_timer)
  {
     healthinc.loc_x = rand()%620 ;
     healthinc.loc_y = -500;     
  }
  
  if (frame_counter == powerinc.spawn_timer)
  {
     powerinc.loc_x = rand()%620 ;
     powerinc.loc_y = -200;
  }
   
  if (player1.health <=0 && player1.state==ALIVE)
  {
      lives-=1;
      if (power_level>1) power_level-=1;
      if (speed>3) speed-=1;
      player1.state = DEAD;
  }
  
  if (player1.shield==ON)
  {
   player1.shield_timer++;
   if (player1.shield_timer==10)
   {
    player1.shield_timer=0;
    player1.shield=OFF;
   }
  }
   
  if (player1.state ==DEAD)
  {
      if (lives>=0)
      {
      player1.explode_timer++;
      if (player1.explode_timer ==100)
      {
       while (i<=30)
       {
        if (enemies[i].loc_y>=0 && enemies[i].loc_y<=480)enemies[i].state=DEAD;
        i++;
       }
       if (i>30) i=1; 
       player1.loc_x = 300;
       player1.loc_y = 400;
       player1.state = ALIVE;
       player1.health=5;
       player1.explode_timer=0;
      }
      }
      
      else if(lives<0) player1.loc_x = -500;              
  }
  
  
   if (frame_counter == 2500)
   {
      while (i<=30)
      { 
       enemies[i].loc_x = rand()%620 ;
       enemies[i].loc_y = rand()%1900 - 1900;          
       enemies[i].state = ALIVE;
       i++;               
      }           
     frame_counter=0;
   }
  if (i>30) i=1;
  
  
  
  if (player1.health==5) health_width=628;
  else if (player1.health==4) health_width=605;
  else if (player1.health==3) health_width=582;
  else if (player1.health==2) health_width=559;
  else if (player1.health==1) health_width=536;
  else if (player1.health==0) health_width=513;
  
  if (power_level ==1) gun_width=552;
  else if (power_level==2) gun_width=588;
  else if (power_level==3) gun_width=624;
  
  if (speed == 3) speed_width = 552;
  else if (speed == 4) speed_width = 588;
  else if (speed == 5) speed_width = 624;                                           
  
  
  
  frame_counter++;
}

void draw_game()
{
 sprintf (score_string, "%i", score);
 sprintf (lives_string, "%i", lives);

 blit(stars,buffer,0,star_scroll*-1,0,0,640,480);
 blit(stars2,buffer,0,star_scroll_2*-1,0,0,640,480);
 

 //draws the power ups
 if (speedinc.loc_y>=-23  && speedinc.loc_y<=480 ) draw_sprite(buffer,speed_up,speedinc.loc_x,speedinc.loc_y);
 if (healthinc.loc_y>=-23) draw_sprite(buffer,health_up,healthinc.loc_x,healthinc.loc_y);
 if (powerinc.loc_y>=-23) draw_sprite(buffer,power_up,powerinc.loc_x,powerinc.loc_y);

 if (playergun_1.loc_y>=-20) draw_sprite(buffer,good_gun,playergun_1.loc_x,playergun_1.loc_y);
 if (playergun_2.loc_y>=-20) draw_sprite(buffer,good_gun,playergun_2.loc_x,playergun_2.loc_y);
 if (playergun_3.loc_y>=-20) draw_sprite(buffer,good_gun,playergun_3.loc_x,playergun_3.loc_y);
 if (playergun_4.loc_y>=-20) draw_sprite(buffer,good_gun,playergun_4.loc_x,playergun_4.loc_y);
 
 player1_anim();
 
 while (i<=30) //draws the enemies to the buffer
 {
  enemy_basic_anim();
 }                    
 if (i>30) i=1;
 
 if (enemygun.loc_y>=-20 && enemygun.loc_y<=500)draw_sprite(buffer, bad_gun, enemygun.loc_x, enemygun.loc_y);
 if (enemygun_2.loc_y>=-20 && enemygun_2.loc_y<=500)draw_sprite(buffer, bad_gun, enemygun_2.loc_x, enemygun_2.loc_y);

 textprintf_ex (buffer, font, 5,450,makecol(255,255,255),0,"Score:");
 textprintf_ex (buffer, font, 5,460,makecol(255,255,255),0,"Lives:");
 textprintf_ex (buffer, font, 450,455,makecol(255,255,255),0,"Shield:");
 textprintf_right_ex (buffer, font, 80,450,makecol(25,255,255),0,score_string);
 
 textprintf_ex (buffer, font, 450,410,makecol(255,255,255),0,"Gun Level:");
 textprintf_ex (buffer, font, 450,430,makecol(255,255,255),0,"Speed Level:");

 if (lives>=0) textprintf_right_ex (buffer, font, 80,460,makecol(25,255,255),0,lives_string);
 else
 {
 textprintf_ex (buffer, font, 70,460,makecol(25,255,255),0,"Game Over.");
 textprintf_centre_ex (buffer, font, 320,240,makecol(255,255,255),0,"Press escape to return to main menu.");
 }
 
 if (player1.shield_timer<=10 && player1.shield==ON  && player1.health>0) 
 {
  circle(buffer, player1.loc_x+12, player1.loc_y+13, 18,makecol(20,20,255));
  circle(buffer, player1.loc_x+12, player1.loc_y+13, 16,makecol(90,90,255));
 }
 
 
 rect (buffer, 550,408,625,415, makecol(200,200,255));
 rectfill (buffer, 551,409,gun_width,414,makecol(255,0,0)); 
 
 rect (buffer, 550,428,625,436, makecol(200,200,255));
 rectfill (buffer, 551,429,speed_width,435,makecol(0,0,255)); 
 
 rect (buffer, 510, 450, 630, 470, makecol(200,200,255)); //draws the shield outer rectangle
 rectfill (buffer,512,452,health_width,468, makecol(255,255,0)); //draws the shield bar, normal (5) is 628 for x2 (x1, y1, x2, y2)
 
 blit(buffer,screen,0,0,0,0,640,480);
 clear_bitmap(buffer);
}

void deinit() {
	clear_keybuf();
	unload_datafile(graphics);
}

void enemy_basic_anim()
{
 if (enemies[i].loc_y>=-25 && enemies[i].state==ALIVE) draw_sprite(buffer, enemy_basic, enemies[i].loc_x, enemies[i].loc_y);
 if (enemies[i].loc_y>=-25 && enemies[i].state==DEAD && enemies[i].explode_timer ==1) draw_rle_sprite(buffer, shockwave_a, enemies[i].loc_x, enemies[i].loc_y);
 else if (enemies[i].loc_y>=-25 && enemies[i].state==DEAD && enemies[i].explode_timer ==2) draw_rle_sprite(buffer, shockwave_b, enemies[i].loc_x-.5, enemies[i].loc_y-.5);
 else if (enemies[i].loc_y>=-25 && enemies[i].state==DEAD && enemies[i].explode_timer ==3) draw_rle_sprite(buffer, shockwave_c, enemies[i].loc_x-1, enemies[i].loc_y-1);
 else if (enemies[i].loc_y>=-25 && enemies[i].state==DEAD && enemies[i].explode_timer ==4) draw_rle_sprite(buffer, shockwave_d, enemies[i].loc_x-1.5, enemies[i].loc_y-1.5);
 else if (enemies[i].loc_y>=-25 && enemies[i].state==DEAD && enemies[i].explode_timer ==5) draw_rle_sprite(buffer, shockwave_e, enemies[i].loc_x-2, enemies[i].loc_y-2);
 else if (enemies[i].loc_y>=-25 && enemies[i].state==DEAD && enemies[i].explode_timer ==6) draw_rle_sprite(buffer, shockwave_f, enemies[i].loc_x-2.5, enemies[i].loc_y-2.5);
 else if (enemies[i].loc_y>=-25 && enemies[i].state==DEAD && enemies[i].explode_timer ==7) draw_rle_sprite(buffer, shockwave_g, enemies[i].loc_x-3, enemies[i].loc_y-3);
 else if (enemies[i].loc_y>=-25 && enemies[i].state==DEAD && enemies[i].explode_timer ==8) draw_rle_sprite(buffer, shockwave_h, enemies[i].loc_x-3.5, enemies[i].loc_y-3.5);
 else if (enemies[i].loc_y>=-25 && enemies[i].state==DEAD && enemies[i].explode_timer ==9) draw_rle_sprite(buffer, shockwave_i, enemies[i].loc_x-4, enemies[i].loc_y-4);
 i++;
}

void player1_anim()
{
 if (player1.state==ALIVE && player1.direction==STRAIGHT) draw_sprite(buffer, myship, player1.loc_x, player1.loc_y);
 else if (player1.state==ALIVE && player1.direction== LEFT) draw_sprite(buffer, myship_left, player1.loc_x, player1.loc_y);
 else if (player1.state==ALIVE && player1.direction== RIGHT) draw_sprite(buffer, myship_right, player1.loc_x, player1.loc_y); 
 if ( player1.state==DEAD && player1.explode_timer ==1) draw_rle_sprite(buffer, shockwave_a, player1.loc_x, player1.loc_y);
 else if ( player1.state==DEAD && player1.explode_timer ==2) draw_rle_sprite(buffer, shockwave_b, player1.loc_x-.5, player1.loc_y-.5);
 else if ( player1.state==DEAD && player1.explode_timer ==3) draw_rle_sprite(buffer, shockwave_c, player1.loc_x-1, player1.loc_y-1);
 else if ( player1.state==DEAD && player1.explode_timer ==4) draw_rle_sprite(buffer, shockwave_d, player1.loc_x-1.5, player1.loc_y-1.5);
 else if ( player1.state==DEAD && player1.explode_timer ==5) draw_rle_sprite(buffer, shockwave_e, player1.loc_x-2, player1.loc_y-2);
 else if ( player1.state==DEAD && player1.explode_timer ==6) draw_rle_sprite(buffer, shockwave_f, player1.loc_x-2.5, player1.loc_y-2.5);
 else if ( player1.state==DEAD && player1.explode_timer ==7) draw_rle_sprite(buffer, shockwave_g, player1.loc_x-3, player1.loc_y-3);
 else if ( player1.state==DEAD && player1.explode_timer ==8) draw_rle_sprite(buffer, shockwave_h, player1.loc_x-3.5, player1.loc_y-3.5);
 else if ( player1.state==DEAD && player1.explode_timer ==9) draw_rle_sprite(buffer, shockwave_i, player1.loc_x-4, player1.loc_y-4);
}

