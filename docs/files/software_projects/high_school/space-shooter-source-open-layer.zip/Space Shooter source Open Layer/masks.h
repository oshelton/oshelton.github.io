/* Allegro datafile object indexes, produced by grabber v4.2.0 (beta4), MinGW32.s */
/* Datafile: c:\Documents and Settings\Big O\My Documents\My programs\Space Shooter source Open Layer\masks.dat */
/* Date: Sun Nov 06 16:56:31 2005 */
/* Do not hand edit! */

#define mask_bullet_enemy                0        /* BMP  */
#define mask_bullet_player               1        /* BMP  */
#define mask_enemy                       2        /* BMP  */
#define mask_item                        3        /* BMP  */
#define mask_player                      4        /* BMP  */

