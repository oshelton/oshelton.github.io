#include "game_units.h"
#include "funct_defs.h"
#include "characters.h"

GfxRend explode;

Bitmap enemy_basic ("Gfx/first_enemy.png");

void enemy_basic_anim()
{
 for (i=0; i<=enemy_small.size(); i++)
 {
  if (enemy_small[i].loc_y>=-25 && enemy_small[i].state==ALIVE && enemy_small[i].loc_y<=640) 
  {
   Blenders::Set(ADDITIVE_BLENDER);
   GfxRend::EllipseSliceGradient(enemy_small[i].loc_x+9, enemy_small[i].loc_y+3,4,rand()%9+15,Rgba(1.0,1.0,1.0,1.0), Rgba(0.0,0.0,0.0,0.0),0,3.14156);
   GfxRend::EllipseSliceGradient(enemy_small[i].loc_x+17, enemy_small[i].loc_y+3,4,rand()%9+15,Rgba(1.0,1.0,1.0,1.0), Rgba(0.0,0.0,0.0,0.0),0,3.14156);
   Blenders::Set(ALPHA_BLENDER);
   enemy_basic.Blit(enemy_small[i].loc_x, enemy_small[i].loc_y);
  }
  if (enemy_small[i].state==DEAD)
  {
  if (enemy_small[i].loc_y>=-25 && enemy_small[i].explode_timer >=1 && enemy_small[i].explode_timer<2) 
  {
   explode.CircleGradient(enemy_small[i].loc_x+12, enemy_small[i].loc_y+12, 15, Rgba(1.0,1.0,0.0,0.9), Rgba(1.0,1.0,0.0,0.0));
   GfxRend::DiskGradient(enemy_small[i].loc_x+12,enemy_small[i].loc_y+12,15,20,Rgba(1.0,1.0,0.0,0.0), Rgba(1.0,0.0,0.0,0.8));
  } 
  else if (enemy_small[i].loc_y>=-25 && enemy_small[i].explode_timer >=2 && enemy_small[i].explode_timer<3)
  {
   explode.CircleGradient(enemy_small[i].loc_x+12, enemy_small[i].loc_y+12, 17, Rgba(1.0,1.0,0.0,1.0), Rgba(1.0,1.0,0.0,0.0));
   GfxRend::DiskGradient(enemy_small[i].loc_x+12,enemy_small[i].loc_y+12,17,22,Rgba(1.0,1.0,0.0,0.0), Rgba(1.0,0.0,0.0,1.0));
  } 
  else if (enemy_small[i].loc_y>=-25  && enemy_small[i].explode_timer >=3 && enemy_small[i].explode_timer<4)
  {
   explode.CircleGradient(enemy_small[i].loc_x+12, enemy_small[i].loc_y+12, 16, Rgba(1.0,1.0,0.0,0.9), Rgba(1.0,1.0,0.0,0.0));
   GfxRend::DiskGradient(enemy_small[i].loc_x+12,enemy_small[i].loc_y+12,19,24,Rgba(1.0,1.0,0.0,0.0), Rgba(1.0,0.0,0.0,0.9));
  } 
  else if (enemy_small[i].loc_y>=-25  && enemy_small[i].explode_timer >=4 && enemy_small[i].explode_timer<5) 
  {
   explode.CircleGradient(enemy_small[i].loc_x+12, enemy_small[i].loc_y+12, 16, Rgba(1.0,1.0,0.0,0.8), Rgba(1.0,1.0,0.0,0.0));
   GfxRend::DiskGradient(enemy_small[i].loc_x+12,enemy_small[i].loc_y+12,21,26,Rgba(1.0,1.0,0.0,0.0), Rgba(1.0,0.0,0.0,0.8));
  } 
  else if (enemy_small[i].loc_y>=-25  && enemy_small[i].explode_timer >=5 && enemy_small[i].explode_timer<6) 
  {
   explode.CircleGradient(enemy_small[i].loc_x+12, enemy_small[i].loc_y+12, 16, Rgba(1.0,1.0,0.0,0.7), Rgba(1.0,1.0,0.0,0.0));
   GfxRend::DiskGradient(enemy_small[i].loc_x+12,enemy_small[i].loc_y+12,23,28,Rgba(1.0,1.0,0.0,0.0), Rgba(1.0,0.0,0.0,0.7));
  }
  else if (enemy_small[i].loc_y>=-25  && enemy_small[i].explode_timer >=6 && enemy_small[i].explode_timer<7) 
  {
   explode.CircleGradient(enemy_small[i].loc_x+12, enemy_small[i].loc_y+12, 16, Rgba(1.0,1.0,0.0,0.6), Rgba(1.0,1.0,0.0,0.0));
   GfxRend::DiskGradient(enemy_small[i].loc_x+12,enemy_small[i].loc_y+12,25,30,Rgba(1.0,1.0,0.0,0.0), Rgba(1.0,0.0,0.0,0.6));
  }
  else if (enemy_small[i].loc_y>=-25  && enemy_small[i].explode_timer >=7 && enemy_small[i].explode_timer<8) 
  {
   explode.CircleGradient(enemy_small[i].loc_x+12, enemy_small[i].loc_y+12, 16, Rgba(1.0,1.0,0.0,0.5), Rgba(1.0,1.0,0.0,0.0));
   GfxRend::DiskGradient(enemy_small[i].loc_x+12,enemy_small[i].loc_y+12,27,32,Rgba(1.0,1.0,0.0,0.0), Rgba(1.0,0.0,0.0,0.5));
  }
  else if (enemy_small[i].loc_y>=-25  && enemy_small[i].explode_timer >=8 && enemy_small[i].explode_timer<9) 
  {
   explode.CircleGradient(enemy_small[i].loc_x+12, enemy_small[i].loc_y+12, 16, Rgba(1.0,1.0,0.0,0.3), Rgba(1.0,1.0,0.0,0.0));
   GfxRend::DiskGradient(enemy_small[i].loc_x+12,enemy_small[i].loc_y+12,29,34,Rgba(1.0,1.0,0.0,0.0), Rgba(1.0,0.0,0.0,0.3));
  }
  else if (enemy_small[i].loc_y>=-25  && enemy_small[i].explode_timer >=9 && enemy_small[i].explode_timer<10) 
  {
   explode.CircleGradient(enemy_small[i].loc_x+12, enemy_small[i].loc_y+12, 16, Rgba(1.0,1.0,0.0,0.1), Rgba(1.0,1.0,0.0,0.0));
   GfxRend::DiskGradient(enemy_small[i].loc_x+12,enemy_small[i].loc_y+12,31,36,Rgba(1.0,1.0,0.0,0.0), Rgba(1.0,0.0,0.0,0.1));
  }
 }
}
}

