/* Allegro datafile object indexes, produced by grabber v4.2.0 (beta4), MinGW32.s */
/* Datafile: c:\Documents and Settings\Big O\My Documents\My programs\Space Shooter source\graphics.dat */
/* Date: Wed Nov 02 17:28:07 2005 */
/* Do not hand edit! */

#define enemybullet                      0        /* BMP  */
#define first_enemy                      1        /* BMP  */
#define gunup                            2        /* BMP  */
#define healthup                         3        /* BMP  */
#define menu_cursor                      4        /* BMP  */
#define my_ship                          5        /* BMP  */
#define my_ship_left                     6        /* BMP  */
#define my_ship_right                    7        /* BMP  */
#define options_background               8        /* BMP  */
#define player_gun                       9        /* BMP  */
#define shockwave_1                      10       /* RLE  */
#define shockwave_2                      11       /* RLE  */
#define shockwave_3                      12       /* RLE  */
#define shockwave_4                      13       /* RLE  */
#define shockwave_5                      14       /* RLE  */
#define shockwave_6                      15       /* RLE  */
#define shockwave_7                      16       /* RLE  */
#define shockwave_8                      17       /* RLE  */
#define shockwave_9                      18       /* RLE  */
#define speedup                          19       /* BMP  */
#define stars_1                          20       /* BMP  */
#define title                            21       /* BMP  */

