#include "characters.h"
#include "funct_defs.h"
#include "game_units.h"


int i_rand;
int i_rand_2;

vector<character> enemy_small; 

SAMPLE *enemy_explode= load_sample("sound_music/boom.wav");

void logic_game()
{
 
 for (i=0; i<=9; i++)
 {
  if (playergun_1[i].loc_x>0 && playergun_1[i].loc_x<800)playergun_1[i].loc_y-=6 * deltaTime;  //move the player's bullet up 6 every cycle.
  if (power_level==2) 
  {
   if (playergun_2[i].loc_x>0 && playergun_2[i].loc_x<800)playergun_2[i].loc_y-=6 * deltaTime;
  }
          
  else if (power_level==3)
  {
   if (playergun_2[i].loc_x>0 && playergun_2[i].loc_x<800)playergun_2[i].loc_y-=(sin_values[110]*6)*deltaTime;
   playergun_2[i].loc_x+=(cos_values[110]*2)*deltaTime;
  }
          
  if (playergun_3[i].loc_x>0 && playergun_3[i].loc_x<800)playergun_3[i].loc_y-=(sin_values[70]*6)* deltaTime;
  playergun_3[i].loc_x+=(cos_values[70]*2)* deltaTime;
 
  if (playergun_1[i].loc_y<-20) playergun_1[i].loc_x=900 ;
  if (playergun_2[i].loc_y<-20) playergun_2[i].loc_x=900 ;
  if (playergun_3[i].loc_y<-20) playergun_3[i].loc_x=900 ;
 }
          
 speedinc.loc_y+=1 * deltaTime;
 healthinc.loc_y+=1 * deltaTime;
 powerinc.loc_y+=1 * deltaTime;
          
 star_scroll+=.5 * deltaTime;
 star_scroll_2+=.5 * deltaTime;
 
 enemygun.loc_y+= 2 * deltaTime;
 enemygun_2.loc_y+= 2 * deltaTime;
  
 for (i=0; i<enemy_small.size(); i++) enemy_small[i].loc_y+= enemy_small[i].speed*deltaTime;                                    
 
          
 //statement for enemy firing
          
 i_rand = rand()%enemy_small.size();        
 i = i_rand;     
 if (enemy_small[i].loc_y>=0 && enemy_small[i].loc_y<=300 && enemygun.loc_y>=700 && !enemy_small[i].state == DEAD)
 {
  enemygun.loc_x = enemy_small[i].loc_x+8;
  enemygun.loc_y = enemy_small[i].loc_y+15;
 }
 
 i_rand = rand()%enemy_small.size();
 i = i_rand;
 if (enemy_small[i].loc_y>=0 && enemy_small[i].loc_y<=500 && enemygun_2.loc_y>=700 && !enemy_small[i].state == DEAD)
 {
  enemygun_2.loc_x = enemy_small[i].loc_x+8;
  enemygun_2.loc_y = enemy_small[i].loc_y+15;
 }
 
 
          
 if (star_scroll >= 600) star_scroll = -600;
  
 if (star_scroll_2 >= 600) star_scroll_2 = -600;
  
  
  //routines for checking for collision between the basic enemy_small and the player bullets.
  
  col_check();
  
  for (i=0; i<enemy_small.size(); i++)
  {
   if (enemy_small[i].health == 0) 
   {
    play_sample(enemy_explode, vol_sound, vol_sound, 1000, 0);
    enemy_small[i].state= DEAD;
    enemy_small[i].explode_timer+=1 *deltaTime;
    if (enemy_small[i].explode_timer ==9) 
    {
     enemy_small[i].loc_x = -50;
     enemy_small[i].explode_timer=0;
     enemy_small[i].state = ALIVE;
     enemy_small[i].health=3;
    }
   }
  } 
  
  
  
  //power up spawn statemnts
  if (frame_counter == speedinc.spawn_timer ||frame_counter==speedinc.spawn_timer*2 ||frame_counter ==speedinc.spawn_timer*3)
  {
     speedinc.loc_x = rand()%620 ;
     speedinc.loc_y = -500;
  }
  
  if (frame_counter == healthinc.spawn_timer || frame_counter ==healthinc.spawn_timer*2 || frame_counter==healthinc.spawn_timer*3)
  {
     healthinc.loc_x = rand()%620 ;
     healthinc.loc_y = -500;     
  }
  
  if (frame_counter == powerinc.spawn_timer || frame_counter ==powerinc.spawn_timer*2 || frame_counter==powerinc.spawn_timer*3)
  {
     powerinc.loc_x = rand()%620 ;
     powerinc.loc_y = -500;
  }
   
  if (player1.health <=0 && player1.state==ALIVE)
  {
      lives-=1;
      
      if (power_level>1) power_level-=1;
      if (player1.speed>3) player1.speed-=1;
      player1.state = DEAD;
  }
  
  if (player1.shield==ON)
  {
   player1.shield_timer+=1 * deltaTime;
   if (player1.shield_timer>=15)
   {
    player1.shield_timer=0;
    player1.shield=OFF;
   }
  }
   
  if (player1.state ==DEAD)
  {
   if (lives>=0)
   {
    player1.explode_timer+=1*deltaTime;
    if (player1.explode_timer >=100)
    {
     for (i=0; i<enemy_small.size(); i++) 
     {
      if (enemy_small[i].loc_y>=0 && enemy_small[i].loc_y<=600)enemy_small[i].health =0;
     }
     player1.loc_x = 300;
     player1.loc_y = 400;
     player1.state = ALIVE;
     player1.health=5;
     player1.explode_timer=0;
    }
  }
      
      else if(lives<0) 
      {
       player1.explode_timer+=1;
       if (player1.explode_timer ==100)
       {
        player1.loc_x = -300;
        player1.loc_y = -400;
        player1.state = DEAD;
        player1.health=0;
        player1.explode_timer=0;
       }
      }            
  }
  
  
  for (i=0; i<enemy_small.size(); i++) 
  {
   if (frame_counter >= enemy_small[i].spawn_timer  && frame_counter <= enemy_small[i].spawn_timer+5) enemy_small[i].loc_y = -30;
  }   
  
  if (player1.health==5) health_width=118;
  else if (player1.health==4) health_width=92;
  else if (player1.health==3) health_width=69;
  else if (player1.health==2) health_width=46;
  else if (player1.health==1) health_width=23;
  else if (player1.health==0) health_width=1;
  
  if (power_level ==1) gun_width=1;
  else if (power_level==2) gun_width=36;
  else if (power_level==3) gun_width=72;
  
  if (player1.speed == 3) speed_width = 1;
  else if (player1.speed == 3.5) speed_width = 36;
  else if (player1.speed == 4) speed_width = 72;                                           
    
  
  frame_counter+=1*deltaTime;
  player1.shot_timer+=1*deltaTime;
  if (player1.shot_timer>=100) player1.shot_timer=0;
}
