
#include <stdio.h>
#include "characters.h"
#include "funct_defs.h"
#include "masks.h"
#include "game_units.h"
#include <pmask.h>



DATAFILE *graphics;
//Declare structure instances (objects)
powerup speedinc;  
powerup healthinc;
powerup powerinc;     

projectile enemygun;
projectile enemygun_2;

character player1;

projectile playergun_1[10];
projectile playergun_2[10]; 
projectile playergun_3[10];

float star_scroll=0;
float star_scroll_2=-600;

int health_width=1;
int gun_width=1;
int speed_width=1;

int power_level = 1;
unsigned int score = 0;
int lives = 2;



int num_small;
int num_med;
int num_large;


unsigned int i=1;  //repeater for the enemy index. mucho importante, do not touch!

struct PMASK *enemybasic_mask, *bullet_mask, *enemy_bullet_mask, *player_mask, *powerup_mask;  //declares the masks used in pixel-perfect collision

void starting_vars()
{
  graphics = load_datafile("masks.dat");
  
  bullet_mask = create_allegro_pmask((BITMAP*)graphics[mask_bullet_player].dat);
  enemy_bullet_mask = create_allegro_pmask((BITMAP*)graphics[mask_bullet_enemy].dat);
  player_mask = create_allegro_pmask((BITMAP*)graphics[mask_player].dat);
  powerup_mask = create_allegro_pmask((BITMAP*)graphics[mask_item].dat);
  enemybasic_mask= create_allegro_pmask((BITMAP*)graphics[mask_enemy].dat);   
  
  cos_table();
  sin_table();
  
  score=0;
  power_level=1;
  player1.speed=3;
  player1.loc_x = 400;
  player1.loc_y = 500;
  lives = 0;
  player1.health = 5;
  player1.state = ALIVE;
  player1.explode_timer=0;
  player1.direction = STRAIGHT;

  speedinc.loc_x = -100;
  speedinc.loc_y = -300;
  speedinc.spawn_timer = rand()%1000 + 1000;

  healthinc.loc_x = -200;
  healthinc.loc_y = -500;
  healthinc.spawn_timer = rand()%1300 + 1000;

  powerinc.loc_x = -120;
  powerinc.loc_y = -400;
  powerinc.spawn_timer = rand()%700 + 1000;

  enemygun.loc_x = -50;
  enemygun.loc_y = -500; 
  
  enemygun_2.loc_x =-200; 
  enemygun_2.loc_y =-500;
  
  load_wave1();
  
  for (i=0; i<enemy_small.size(); i++)
  {
   enemy_small[i].loc_y = -3000;
   enemy_small[i].health= 2;
   enemy_small[i].speed = 1;
   enemy_small[i].state = ALIVE;
   enemy_small[i].explode_timer=0;        
  }
  
  
  for (i=0; i<=9; i++)
  { 
   playergun_1[i].loc_x = 2000;
   playergun_1[i].loc_y = -1000;

   playergun_2[i].loc_x = 2000;
   playergun_2[i].loc_y = -1000;

   playergun_3[i].loc_x = 2000;
   playergun_3[i].loc_y = -1000;
  }   
}   


void deinit() {
	clear_keybuf();
}

