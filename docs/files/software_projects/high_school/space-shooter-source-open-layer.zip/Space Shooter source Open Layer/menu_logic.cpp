#include "funct_defs.h"

void logic_menu() 
{
 choice_delay+=1 *deltaTime;
 sprintf (g_mode_string, "%i", g_mode);
}
