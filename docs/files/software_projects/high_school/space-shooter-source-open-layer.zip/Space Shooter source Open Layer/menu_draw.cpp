#include "menu_functions.h"
#include "funct_defs.h"

Bitmap title_image ("Gfx/title_screen.png");
Bitmap options_image ("Gfx/sub_menu_options.png");

void draw_menu()
{
 GfxRend::FillScreen(Rgba::BLACK);
 if (menu==MAIN_MENU) title_image.Blit(0,0);
 else if(menu == OPTIONS_MENU) 
 {
  options_image.Blit(0,0);
  GfxRend::Rect (255, 235, 265, 40, Rgba::BLACK);
  GfxRend::Rect (255, 305, 265, 40, Rgba::BLACK);
  GfxRend::Rect (260, 240, vol_sound, 30, Rgba::YELLOW);
  GfxRend::Rect (260, 310, vol_music, 30, Rgba::YELLOW);
 } 
  
 if (choice ==START) GfxRend::RectOutline(295,380,250,30, Rgba(.7,.7,1.0),2.0); 
 else if (choice ==HELP) GfxRend::RectOutline(355,425,105,30,Rgba(.7,.7,1.0),2.0 );//360,450
 else if (choice ==OPTIONS) GfxRend::RectOutline(325,465,175,30,Rgba(.7,.7,1.0),2.0);//330,490
 else if (choice ==EXIT) GfxRend::RectOutline(365,515,90,30, Rgba(.7,.7,1.0),2.0);//370,540
 else if (choice ==BACK) GfxRend::RectOutline(325,535,125,27,Rgba(.7,.7,1.0),2.0);
 else if (choice ==WIND) GfxRend::RectOutline(250,118,280,15, Rgba(.7,.7,1.0),1.0);
 else if (choice ==FULLS) GfxRend::RectOutline(250,138,280,15, Rgba(.7,.7,1.0),1.0);
}
