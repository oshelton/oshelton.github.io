#include "characters.h"
#include "funct_defs.h"
#include "game_units.h"
#include "masks.h"
#include <pmask.h>

unsigned int j=0;

SAMPLE *s_hit= load_sample("sound_music/shield_hit.wav");

void col_check()
{
 for (i=0; i<enemy_small.size(); i++)
  { 
   if (enemy_small[i].loc_y>=-30 && enemy_small[i].loc_y<=600)
   {
    for (j=0; j<=9; j++)
    {
    if (check_pmask_collision(enemybasic_mask, bullet_mask, enemy_small[i].loc_x, enemy_small[i].loc_y, playergun_1[j].loc_x, playergun_1[j].loc_y)  && enemy_small[i].state ==ALIVE)
    {
     enemy_small[i].health -=1;
     playergun_1[j].loc_x = 900;
     playergun_1[j].loc_y = -1;
    
     if (enemy_small[i].loc_y<= player1.loc_y-100) score+=2;
     else score+= 3;            
    }
   
    if (check_pmask_collision(enemybasic_mask, bullet_mask, enemy_small[i].loc_x, enemy_small[i].loc_y, playergun_2[j].loc_x, playergun_2[j].loc_y)  && enemy_small[i].state ==ALIVE)
    {
     enemy_small[i].health -= 1;
     playergun_2[j].loc_x = 900;
     playergun_2[j].loc_y = -1;
    
     if (enemy_small[i].loc_y<= player1.loc_y-100) score+=2;
     else score+= 3;                        
    }
   
    if (check_pmask_collision(enemybasic_mask, bullet_mask, enemy_small[i].loc_x, enemy_small[i].loc_y, playergun_3[j].loc_x, playergun_3[j].loc_y) && enemy_small[i].state==ALIVE)
    {            
     enemy_small[i].health -= 1;
     playergun_3[j].loc_x = 900;
     playergun_3[j].loc_y = -1;
    
     if (enemy_small[i].loc_y<= player1.loc_y-100) score+=2;
     else score+= 3;
    }
   } 
   
   if (check_pmask_collision(enemybasic_mask, player_mask, enemy_small[i].loc_x , enemy_small[i].loc_y, player1.loc_x, player1.loc_y) && enemy_small[i].state ==ALIVE && player1.state==ALIVE)
   {              
      enemy_small[i].health = 0;
      player1.health -=1;
      
      player1.shield = ON;
      player1.shield_timer = 0;
      play_sample(s_hit, vol_sound, vol_sound, 1000, 0);
   } 
  } 
  }
  
  if (enemygun.loc_y>=-20 && enemygun.loc_y<=600)
  {
  if (check_pmask_collision(player_mask, enemy_bullet_mask, player1.loc_x, player1.loc_y, enemygun.loc_x, enemygun.loc_y) && player1.state==ALIVE)
   {
    enemygun.loc_x = -50;
    player1.health -=1;
    
    player1.shield = ON;
    player1.shield_timer = 0;
    play_sample(s_hit, vol_sound, vol_sound, 1000, 0);
   }
  }
   
  if (enemygun_2.loc_y>=-20 && enemygun_2.loc_y<=600)
  { 
   if (check_pmask_collision(player_mask, enemy_bullet_mask, player1.loc_x, player1.loc_y, enemygun_2.loc_x, enemygun_2.loc_y))
   {
    enemygun_2.loc_x = -100;
    player1.health -=1;
    
    player1.shield = ON;
    player1.shield_timer = 0;
    play_sample(s_hit, vol_sound, vol_sound, 1000, 0);
   }
  }               
  //begins routine for checking collision with speed_up powerup
  if (check_pmask_collision(powerup_mask, player_mask, speedinc.loc_x, speedinc.loc_y, player1.loc_x, player1.loc_y) && player1.state==ALIVE ) 
  {
     if (player1.speed<=4) player1.speed+=.5;
     else score+=5;
     speedinc.loc_x = -200;
     speedinc.loc_y = -200;
  }
  //health powerup
  if (check_pmask_collision(powerup_mask, player_mask, healthinc.loc_x, healthinc.loc_y, player1.loc_x, player1.loc_y) && player1.state==ALIVE) 
  {
     if (player1.health<5) player1.health+=1;
     else score+=5;
     healthinc.loc_x = -200;
     healthinc.loc_y = -200;
  }
  //power power up
  if (check_pmask_collision(powerup_mask, player_mask, powerinc.loc_x, powerinc.loc_y, player1.loc_x, player1.loc_y) && player1.state==ALIVE) 
  {
     if (power_level==1) power_level+=1;
     else if(power_level ==2) power_level+=1;
     else score+=5;
     powerinc.loc_x = -200;
     powerinc.loc_y = -200;
  }
}
