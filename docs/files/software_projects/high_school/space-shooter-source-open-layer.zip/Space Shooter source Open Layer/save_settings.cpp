#include <stdio.h>
#include "funct_defs.h"

char g_mode_string[24];


void save_settings()
{
 
 game_settings = fopen("data/settings.txt", "w");
 
 fputs ("[screen]\n", game_settings);
 fputs (g_mode_string, game_settings);
 
 fclose (game_settings);
}

