#include "funct_defs.h"

using namespace ol;

void init()
{
 Setup::SetupProgram();
 Setup::SetupScreen(800,600,WINDOWED);
 
 
 FpsCounter::Start( 100.0 );
}

void new_frame()
{
 FpsCounter::NewFrameStarted();
}

void check_time()
{
 float deltaTime = FpsCounter::GetDeltaTime();
 GfxRend::RefreshScreen();
}
