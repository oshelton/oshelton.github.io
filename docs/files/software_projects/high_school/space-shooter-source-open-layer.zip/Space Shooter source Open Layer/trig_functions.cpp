#include <math.h>
#include "funct_defs.h"

unsigned int k = 1;
float cos_values[361];
float sin_values[361];

void cos_table()
{
 for (k=0; k<=360; k++) cos_values[k] = cos(k*pi/180) ;
}

void sin_table()
{
 for (k=0; k<=360; k++) sin_values[k] = sin(k*pi/180);
} 
 

