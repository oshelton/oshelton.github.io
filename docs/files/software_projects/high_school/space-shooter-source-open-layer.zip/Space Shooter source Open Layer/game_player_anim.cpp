#include "game_units.h"
#include "funct_defs.h"
#include "characters.h"

Bitmap myship ("Gfx/player_ship.png");
Bitmap myship_left ("Gfx/player_ship_left.png");
Bitmap myship_right ("Gfx/player_ship_right.png");

void player1_anim()
{
 if (player1.state==ALIVE && player1.direction==STRAIGHT) 
 {
  Blenders::Set(ADDITIVE_BLENDER);
  GfxRend::EllipseSliceGradient(player1.loc_x+19.5, player1.loc_y+48,5,rand()%9+20,Rgba(1.0,1.0,0.0,1.0), Rgba(0.0,0.0,0.0,0.0),0,-3.14156);
  GfxRend::EllipseSliceGradient(player1.loc_x+31.0, player1.loc_y+48,5,rand()%9+20,Rgba(1.0,1.0,0.0,1.0), Rgba(0.0,0.0,0.0,0.0),0,-3.14156);
  Blenders::Set(ALPHA_BLENDER);
  myship.Blit( player1.loc_x, player1.loc_y);  
 }
 else if (player1.state==ALIVE && player1.direction== LEFT) 
 {
  Blenders::Set(ADDITIVE_BLENDER);
  GfxRend::EllipseSliceGradient(player1.loc_x+19.5, player1.loc_y+47,4,rand()%9+20,Rgba(1.0,1.0,0.0,1.0), Rgba(0.0,0.0,0.0,0.0),0,-3.14156);
  GfxRend::EllipseSliceGradient(player1.loc_x+30.5, player1.loc_y+48,5,rand()%9+20,Rgba(1.0,1.0,0.0,1.0), Rgba(0.0,0.0,0.0,0.0),0,-3.14156);
  Blenders::Set(ALPHA_BLENDER);
  myship_left.Blit( player1.loc_x, player1.loc_y);
 }
  
 else if (player1.state==ALIVE && player1.direction== RIGHT) 
 {
  Blenders::Set(ADDITIVE_BLENDER);
  GfxRend::EllipseSliceGradient(player1.loc_x+19.5, player1.loc_y+48,5,rand()%9+20,Rgba(1.0,1.0,0.0,1.0), Rgba(0.0,0.0,0.0,0.0),0,-3.14156);
  GfxRend::EllipseSliceGradient(player1.loc_x+31.0, player1.loc_y+47,4,rand()%9+20,Rgba(1.0,1.0,0.0,1.0), Rgba(0.0,0.0,0.0,0.0),0,-3.14156);
  Blenders::Set(ALPHA_BLENDER);
  myship_right.Blit( player1.loc_x, player1.loc_y);
 } 
 if (player1.state==DEAD)
 {
  
  
 
 if ( player1.explode_timer >=1 && player1.explode_timer<2)
 {  
  gfx.CircleGradient(player1.loc_x+25, player1.loc_y+25, 30,Rgba (1.0,1.0,0.0,0.8), Rgba(1.0,1.0,0.0,0.0));
  GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 26, 41, Rgba(1.0,0.0,0.0,0.), Rgba(1.0,1.0,0.0,0.5));
 }  
 else if ( player1.explode_timer >=2 && player1.explode_timer<4)
 {
  gfx.CircleGradient(player1.loc_x+25, player1.loc_y+25, 31,Rgba (1.0,1.0,0.0,0.9), Rgba(1.0,1.0,0.0,0.0));
  GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 29, 44, Rgba(1.0,0.0,0.0,0.0), Rgba(1.0,1.0,0.0,0.5));
 } 
 else if (  player1.explode_timer >=4 && player1.explode_timer<6) 
 {
  gfx.CircleGradient(player1.loc_x+25, player1.loc_y+25, 32,Rgba (1.0,1.0,0.0,1.0), Rgba(1.0,1.0,0.0,0.0));
  GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 32, 47, Rgba(1.0,0.0,0.0,0.0), Rgba(1.0,1.0,0.0,0.6));
 }
 else if (  player1.explode_timer >=6 && player1.explode_timer<8)
 {
  
  gfx.CircleGradient(player1.loc_x+25, player1.loc_y+25, 33,Rgba (1.0,1.0,0.0,1.0), Rgba(1.0,1.0,0.0,0.0));
  GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 35, 50, Rgba(1.0,0.0,0.0,0.0), Rgba(1.0,1.0,0.0,0.6));
 } 
 else if (  player1.explode_timer >=8 && player1.explode_timer<10)
 {
  gfx.CircleGradient(player1.loc_x+25, player1.loc_y+25, 33,Rgba (1.0,1.0,0.0,1.0), Rgba(1.0,1.0,0.0,0.0));
  GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 38, 53, Rgba(1.0,0.0,0.0,0.0), Rgba(1.0,1.0,0.0,0.7));
 } 
 else if (  player1.explode_timer >=10 && player1.explode_timer<12)
 {
  gfx.CircleGradient(player1.loc_x+25, player1.loc_y+25, 34,Rgba (1.0,1.0,0.0,1.0), Rgba(1.0,1.0,0.0,0.0));
  GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 41, 56, Rgba(1.0,0.0,0.0,0.0), Rgba(1.0,1.0,0.0,0.7));
 }
 else if (  player1.explode_timer >=12 && player1.explode_timer<14)
 {
  gfx.CircleGradient(player1.loc_x+25, player1.loc_y+25, 34,Rgba (1.0,1.0,0.0,1.0), Rgba(1.0,1.0,0.0,0.0));
  GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 44, 59, Rgba(1.0,0.0,0.0,0.0), Rgba(1.0,1.0,0.0,0.8));
 } 
 else if (  player1.explode_timer >=14 && player1.explode_timer<16)
 {
  gfx.CircleGradient(player1.loc_x+25, player1.loc_y+25, 35,Rgba (1.0,1.0,0.0,1.0), Rgba(1.0,1.0,0.0,0.0));
  GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 47, 62, Rgba(1.0,0.0,0.0,0.0), Rgba(1.0,1.0,0.0,0.9));
 } 
 else if (  player1.explode_timer >=16 && player1.explode_timer<18)
 {
  gfx.CircleGradient(player1.loc_x+25, player1.loc_y+25, 35,Rgba (1.0,1.0,0.0,1.0), Rgba(1.0,1.0,0.0,0.0));
  GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 50, 65, Rgba(1.0,0.0,0.0,0.0), Rgba(1.0,1.0,0.0,0.9));
 } 
 else if (  player1.explode_timer >=18 && player1.explode_timer<20)
 {
  gfx.CircleGradient(player1.loc_x+25, player1.loc_y+25, 36,Rgba (1.0,1.0,0.0,1.0), Rgba(1.0,1.0,0.0,0.0));
  GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 53, 68, Rgba(1.0,0.0,0.0,0.0), Rgba(1.0,1.0,0.0,1.0));
 }
 else if (  player1.explode_timer >=20 && player1.explode_timer<22)
 {
  gfx.CircleGradient(player1.loc_x+25, player1.loc_y+25, 36,Rgba (1.0,1.0,0.0,1.0), Rgba(1.0,1.0,0.0,0.0));
  GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 56, 71, Rgba(1.0,0.0,0.0,0.0), Rgba(1.0,1.0,0.0,1.0));
 }
 else if (  player1.explode_timer >=22 && player1.explode_timer<24)
 {
  gfx.CircleGradient(player1.loc_x+25, player1.loc_y+25, 35,Rgba (1.0,1.0,0.0,0.9), Rgba(1.0,1.0,0.0,0.0));
  GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 59, 74, Rgba(1.0,0.0,0.0,0.0), Rgba(1.0,1.0,0.0,0.9));
 }
 else if (  player1.explode_timer >=24 && player1.explode_timer<26)
 {
  gfx.CircleGradient(player1.loc_x+25, player1.loc_y+25, 35,Rgba (1.0,1.0,0.0,0.9), Rgba(1.0,1.0,0.0,0.0));
  GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 62, 77, Rgba(1.0,0.0,0.0,0.0), Rgba(1.0,1.0,0.0,0.9));
 }
 else if (  player1.explode_timer >=26 && player1.explode_timer<28)
 {
  gfx.CircleGradient(player1.loc_x+25, player1.loc_y+25, 34,Rgba (1.0,1.0,0.0,0.8), Rgba(1.0,1.0,0.0,0.0));
  GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 65, 80, Rgba(1.0,0.0,0.0,0.0), Rgba(1.0,1.0,0.0,0.7));
 }
 else if (  player1.explode_timer >=28 && player1.explode_timer<30)
 {
  gfx.CircleGradient(player1.loc_x+25, player1.loc_y+25, 34,Rgba (1.0,1.0,0.0,0.8), Rgba(1.0,1.0,0.0,0.0));
  GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 68, 83, Rgba(1.0,0.0,0.0,0.0), Rgba(1.0,1.0,0.0,0.6));
 }
 else if (  player1.explode_timer >=30 && player1.explode_timer<32)
 {
  gfx.CircleGradient(player1.loc_x+25, player1.loc_y+25, 33,Rgba (1.0,1.0,0.0,0.7), Rgba(1.0,1.0,0.0,0.0));
  GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 71, 86, Rgba(1.0,0.0,0.0,0.0), Rgba(1.0,1.0,0.0,0.5));
 }
 else if (  player1.explode_timer >=32 && player1.explode_timer<34)
 {
  gfx.CircleGradient(player1.loc_x+25, player1.loc_y+25, 32,Rgba (1.0,1.0,0.0,0.7), Rgba(1.0,1.0,0.0,0.0));
  GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 74, 89, Rgba(1.0,0.0,0.0,0.0), Rgba(1.0,1.0,0.0,0.4));
 }
 else if (  player1.explode_timer >=34 && player1.explode_timer<36)
 {
  gfx.CircleGradient(player1.loc_x+25, player1.loc_y+25, 31,Rgba (1.0,1.0,0.0,0.6), Rgba(1.0,1.0,0.0,0.0));
  GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 77, 92, Rgba(1.0,0.0,0.0,0.0), Rgba(1.0,1.0,0.0,0.3));
 }
 else if (  player1.explode_timer >=36 && player1.explode_timer<38)
 {
  gfx.CircleGradient(player1.loc_x+25, player1.loc_y+25, 30,Rgba (1.0,1.0,0.0,0.6), Rgba(1.0,1.0,0.0,0.0));
  GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 80, 95, Rgba(1.0,0.0,0.0,0.0), Rgba(1.0,1.0,0.0,0.2));
 }
 else if (  player1.explode_timer >=38 && player1.explode_timer<40)
 {
  gfx.CircleGradient(player1.loc_x+25, player1.loc_y+25, 30,Rgba (1.0,1.0,0.0,0.5), Rgba(1.0,1.0,0.0,0.0));
  GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 83, 98, Rgba(1.0,0.0,0.0,0.0), Rgba(1.0,1.0,0.0,0.1));
 }
 
}
} 


