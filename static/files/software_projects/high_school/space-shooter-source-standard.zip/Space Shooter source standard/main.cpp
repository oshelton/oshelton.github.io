
#include <allegro.h>
#include <stdio.h>
#include <pmask.h>
#include "graphics.h"
#include "characters.h"
#include "funct_defs.h"




volatile long speed_counter = 0; // A long integer which will store the value of the timer used in the program.  COntrols the program cycle.




short game_on = TRUE; //global start game variable
int mode = MENU;

int main(int argc, char *argv[]) {
	
    init();
    set_graphics();
    starting_vars();
    set_menu_graphics();
    set_menu_vars();
    
        		    	    
    while (game_on ==TRUE) {
      while(speed_counter > 0)
          { 
          if (mode == MENU)
          {
           input_menu();
           logic_menu();
          }
          
          else if (mode==GAME)
          {
           input_game();
           logic_game();
          }
          
          speed_counter--;
          }
          if (mode ==MENU) draw_menu();
          else if (mode==GAME) draw_game();
         }
    deinit();	
	return 0;
}
END_OF_MAIN();


void increment_speed_counter() // A function to increment the speed counter
{
  speed_counter++; // This will just increment the speed counter by one. :)
}
END_OF_FUNCTION(increment_speed_counter); // Make sure you tell it that it's the end of the
                                                                 // function

