#include "menu_functions.h"
#include "graphics.h"
#include "funct_defs.h"



using namespace ol;

short choice;
float choice_delay;
unsigned int menu;

float frame_counter;

bool g_mode;

void set_menu_vars()
{
 menu = MAIN_MENU;
 choice = START;
 choice_delay=0;
}
