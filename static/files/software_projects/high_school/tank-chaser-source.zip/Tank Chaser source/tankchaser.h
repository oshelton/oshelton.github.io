/* Allegro datafile object indexes, produced by grabber v4.2.0 (beta4), MinGW32.s */
/* Datafile: c:\Documents and Settings\Big O\My Documents\My programs\Tank Chaser\graphics.dat */
/* Date: Thu Sep 29 19:31:55 2005 */
/* Do not hand edit! */

#define d_block                          0        /* BMP  */
#define d_desert                         1        /* BMP  */
#define d_rad                            2        /* BMP  */
#define d_rusty                          3        /* BMP  */
#define d_score_block                    4        /* BMP  */
#define d_start                          5        /* BMP  */
#define d_sub_menu1                      6        /* BMP  */
#define d_sub_menu2                      7        /* BMP  */
#define d_tank                           8        /* BMP  */
#define d_timer                          9        /* BMP  */
#define d_title                          10       /* BMP  */
#define d_win                            11       /* BMP  */

