#ifndef funct_def_h
#define funct_def_h
#include <allegro.h>

#define pi 3.14156

#define DEAD 0
#define ALIVE 1

#define ON 100
#define OFF 101

#define MENU 2
#define GAME 3

#define MAIN_MENU 20
#define HELP_MENU 21
#define OPTIONS_MENU 22

#define WINDOW 0
#define FULL 1

//declare special global variables

extern short game_on;
extern int mode; 
extern int g_mode; 
 

extern DATAFILE *graphics;
extern BITMAP *buffer;

void increment_speed_counter();

//declare menu functuions
void set_menu_graphics();
void set_menu_vars();
void input_menu();
void logic_menu();
void draw_menu();

//declare in-game functions

void init();
void set_graphics();
void starting_vars();
void input_game();
void logic_game();
void draw_game();
void deinit(); //voids the deinit (clear_keybuf()) function, a bit of a waiste.

//declare trig functions and variables
extern float cos_values[360];
extern float sin_values[360];

void cos_table();
void sin_table();

#endif
