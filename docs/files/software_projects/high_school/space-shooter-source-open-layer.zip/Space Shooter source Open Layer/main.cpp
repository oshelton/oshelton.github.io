#include <OpenLayer.hpp>
#include <string>
#include "funct_defs.h"
#include "characters.h"
#include "game_units.h"

using namespace std;
using namespace ol;

TextRenderer game_standard( "Fonts/Neuropol.ttf", 22, 15, Rgba::WHITE ); 	
TextRenderer game_big( game_standard, 40, 30 );

string start = "Start Game";
string help = "Help";
string options = "Options";
string quit = "Exit";
string status_string;

float deltaTime;



Bitmap cursor ("Gfx/cursor.png");
double cursor_rot;
int cursor_x;
int cursor_y;

int vol_sound=255; 
int vol_music=255;

short game_on = TRUE; //global start game variable
unsigned short mode = MENU;
bool state=RUNNING;

int main()
{
 load_settings();
 Setup::SetupProgram();
 if (g_mode==1)Setup::SetupScreen(800,600, FULLSCREEN,32);
 else Setup::SetupScreen(800,600, WINDOWED,32);
 install_sound(DIGI_AUTODETECT,MIDI_AUTODETECT,NULL);
 FpsCounter::Start( 90 );
 
 Blenders::Set( ALPHA_BLENDER);
 
 set_menu_vars();
 starting_vars();
 
 while (game_on==TRUE)
 {
 
  FpsCounter::NewFrameStarted(); 
  
  if (mode == MENU)
  {
   input_menu();
   logic_menu();
   draw_menu();
   if (menu==MAIN_MENU)
   {
    game_big.Print(quit, 370,540);
    game_big.Print(start, 300, 405);
    game_big.Print(help,360, 450);
    game_big.Print(options,330,490);
   }
   else if (menu ==OPTIONS_MENU)
   {
    game_big.Print ("Options", 310,40);
    game_standard.Print ("800 x 600 Windowed", 255, 130);
    game_standard.Print ("800 x 600 Fullscreen", 258, 150);
    game_standard.Print ("Sound Volume", 300, 220);
    game_standard.Print ("Music Volume", 300, 290);
    game_big.Print ("Back", 330, 560);
   }
   cursor_rot+=.04 * deltaTime;
   cursor.BlitRotated(cursor_x,cursor_y, cursor_rot);
  }
  
  else if (mode==GAME)
  {
   if (state == RUNNING)
   {
    input_game();
    logic_game();
   }
   spec_input_game();
   draw_game();
   if (state==PAUSED) game_standard.Print("Game is paused, press p to resume.",200,300);
   
   string status_string = "Score:  " + ToString( int(score)) +"\nLives:  " + ToString( int(lives));
   game_standard.Print(status_string,50,550);
   game_standard.Print("Guns:\n\nSpeed:\n\nHealth: ",560,505);
   if (lives<0) game_standard.Print("Game over, press q to return to main menu",180,300);
  }
  cursor_x = mouse_x;
  cursor_y = mouse_y; 
  
  string fps_counter= "FPS: " + ToString( int( FpsCounter::GetFps() ));
  game_standard.Print (fps_counter,25,25);
  game_standard.Print (ToString(int(frame_counter)), 25,40);     
  GfxRend::RefreshScreen();
  
  deltaTime = FpsCounter::GetDeltaTime();
 } 
}
END_OF_MAIN()
