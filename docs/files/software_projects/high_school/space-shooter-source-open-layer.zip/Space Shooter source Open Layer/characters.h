#include <vector>

using namespace std;

extern unsigned int i;  //repeater for the enemy index. mucho importante, do not touch!

struct character
{
       float loc_x;
       float loc_y;
       
       float speed;
       int health; 
       short state;
       int direction;
       unsigned int shield;
       
       float shot_timer;
       float explode_timer;
       float shield_timer;
       float spawn_timer;      
};



struct powerup
{
      int loc_x;
      double loc_y;
      
      unsigned int spawn_timer; 
};

struct projectile
{
       float loc_x;
       float loc_y;
};     

extern vector<character> enemy_small;



