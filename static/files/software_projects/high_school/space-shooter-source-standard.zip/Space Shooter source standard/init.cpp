#include "funct_defs.h"

void init()
{
 int depth, res;  //declares the color depth and resolution variables
 allegro_init();  //initializes the Allgro specific functions
 install_timer();  //installs the timer
 install_keyboard();  
 install_mouse();
 depth = desktop_color_depth();  //sets depth = the return value of function desktop_color_depth
 if (depth == 0) depth = 16;  //sets the color depth to 32
 set_color_depth(depth);
 res = set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0); //sets the graphics mode
 install_sound(DIGI_AUTODETECT,MIDI_AUTODETECT,NULL);
 if (res != 0) {    //error checking for the resollution
	allegro_message(allegro_error);
	exit(-1);
            }

 LOCK_VARIABLE(speed_counter); //Used to set the timer - which regulates the game's
 LOCK_FUNCTION(increment_speed_counter);//speed.

 install_int_ex(increment_speed_counter, BPS_TO_TIMER(60));//Set our BPS, our the speed of our game
}
