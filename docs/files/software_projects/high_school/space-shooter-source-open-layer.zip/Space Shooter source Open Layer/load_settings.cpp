#include <stdio.h>
#include "funct_defs.h"

char junk[128];
FILE *game_settings;

void load_settings()
{
 game_settings = fopen("data/settings.txt", "r");
 
 fscanf (game_settings, "%s\n", &junk);
 fscanf (game_settings, "%i\n", &g_mode);
 
 fclose (game_settings);
}
 
