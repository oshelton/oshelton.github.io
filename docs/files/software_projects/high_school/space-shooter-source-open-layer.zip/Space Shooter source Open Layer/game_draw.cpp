#include <stdio.h>
#include "characters.h"
#include "funct_defs.h"
#include "game_units.h"

using namespace ol;

Bitmap stars ("Gfx/starfield.png");
Bitmap stars2 ("Gfx/starfield.png");

Bitmap good_gun = ("Gfx/gun.png");
Bitmap bad_gun = ("Gfx/enemy_gun.png");
Bitmap speed_up = ("Gfx/speed.png");
Bitmap health_up = ("Gfx/health.png");
Bitmap power_up = ("Gfx/power.png");	



void draw_game()
{
 GfxRend::FillScreen(Rgba::BLACK);
 
 stars.Blit(0,star_scroll);
 stars2.Blit(0,star_scroll_2);
 

 //draws the power ups
 if (speedinc.loc_y>=-23  && speedinc.loc_y<=620 ) speed_up.Blit(speedinc.loc_x,speedinc.loc_y);
 if (healthinc.loc_y>=-23 && healthinc.loc_y<=620) health_up.Blit(healthinc.loc_x,healthinc.loc_y);
 if (powerinc.loc_y>=-23 && powerinc.loc_y<=620) power_up.Blit(powerinc.loc_x,powerinc.loc_y);

 for (i=0; i<=9; i++)
 {
  if (playergun_1[i].loc_y>=-20) good_gun.Blit(playergun_1[i].loc_x,playergun_1[i].loc_y);
  if (playergun_2[i].loc_y>=-20) good_gun.Blit(playergun_2[i].loc_x,playergun_2[i].loc_y);
  if (playergun_3[i].loc_y>=-20) good_gun.Blit(playergun_3[i].loc_x,playergun_3[i].loc_y);
 }
 
 player1_anim();  
 enemy_basic_anim();
 
 if (enemygun.loc_y>=-20 && enemygun.loc_y<=600) bad_gun.Blit(enemygun.loc_x, enemygun.loc_y);
 if (enemygun_2.loc_y>=-20 && enemygun_2.loc_y<=600) bad_gun.Blit(enemygun_2.loc_x, enemygun_2.loc_y);

 if (player1.shield==ON  && player1.health>0) 
 {
  Blenders::Set(ADDITIVE_BLENDER);
  if (player1.shield_timer>=1 && player1.shield_timer<2) GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 30,40,Rgba(1.0,1.0,1.0,1.0), Rgba(0.0,0.0,1.0,1.0));
  else if (player1.shield_timer>=2 && player1.shield_timer<3) GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 31,42,Rgba(1.0,1.0,1.0,0.9), Rgba(0.0,0.0,1.0,0.9));
  else if (player1.shield_timer>=3 && player1.shield_timer<4) GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 32,44,Rgba(1.0,1.0,1.0,0.8), Rgba(0.0,0.0,1.0,0.8));
  else if (player1.shield_timer>=4 && player1.shield_timer<5) GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 33,46,Rgba(1.0,1.0,1.0,0.8), Rgba(0.0,0.0,1.0,0.8));
  else if (player1.shield_timer>=5 && player1.shield_timer<6) GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 34,48,Rgba(1.0,1.0,1.0,0.7), Rgba(0.0,0.0,1.0,0.7));
  else if (player1.shield_timer>=6 && player1.shield_timer<7) GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 35,50,Rgba(1.0,1.0,1.0,0.7), Rgba(0.0,0.0,1.0,0.7));
  else if (player1.shield_timer>=7 && player1.shield_timer<8) GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 36,52,Rgba(1.0,1.0,1.0,0.6), Rgba(0.0,0.0,1.0,0.6));
  else if (player1.shield_timer>=8 && player1.shield_timer<9) GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 37,54,Rgba(1.0,1.0,1.0,0.6), Rgba(0.0,0.0,1.0,0.6));
  else if (player1.shield_timer>=9 && player1.shield_timer<10) GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 38,56,Rgba(1.0,1.0,1.0,0.5), Rgba(0.0,0.0,1.0,0.5));
  else if (player1.shield_timer>=10 && player1.shield_timer<11) GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 39,58,Rgba(1.0,1.0,1.0,0.5), Rgba(0.0,0.0,1.0,0.5));
  else if (player1.shield_timer>=11 && player1.shield_timer<12) GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 40,60,Rgba(1.0,1.0,1.0,0.4), Rgba(0.0,0.0,1.0,0.4));
  else if (player1.shield_timer>=12 && player1.shield_timer<13) GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 42,64,Rgba(1.0,1.0,1.0,0.3), Rgba(0.0,0.0,1.0,0.3));
  else if (player1.shield_timer>=13 && player1.shield_timer<14) GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 43,66,Rgba(1.0,1.0,1.0,0.3), Rgba(0.0,0.0,1.0,0.3));
  else if (player1.shield_timer>=14 && player1.shield_timer<15) GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 44,68,Rgba(1.0,1.0,1.0,0.2), Rgba(0.0,0.0,1.0,0.2));
  else if (player1.shield_timer>=15) GfxRend::DiskGradient(player1.loc_x+25, player1.loc_y+25, 45,70,Rgba(1.0,1.0,1.0,0.1), Rgba(0.0,0.0,1.0,0.1));
  Blenders::Set(ALPHA_BLENDER);
 } 
 
 Blenders::Set(ADDITIVE_BLENDER);
 GfxRend::RectOutline ( 660,502,75,7, Rgba(0.8,0.8,1.0));
 GfxRend::Rect (661,503,gun_width,6,Rgba(1.0,0.0,0.0,0.7)); 
 
 GfxRend::RectOutline ( 660,522,75,7, Rgba(0.8,0.8,1.0));
 GfxRend::Rect ( 661,523,speed_width,6,Rgba(0.0,0.0,1.0,0.7)); 
 
 GfxRend::RectOutline ( 660, 540, 120, 20, Rgba(0.8,0.8,1.0)); //draws the shield outer rectangle
 GfxRend::Rect ( 661,541,health_width,19, Rgba(1.0,1.0,0.0)); //draws the shield bar, normal (5) is 628 for x2 (x1, y1, x2, y2)
 Blenders::Set(ALPHA_BLENDER);
}



