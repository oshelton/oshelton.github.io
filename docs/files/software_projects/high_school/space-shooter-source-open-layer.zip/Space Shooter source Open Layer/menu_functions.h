#include <openlayer.hpp>
#include "funct_defs.h"

#define START 0
#define HELP  1
#define OPTIONS 2
#define EXIT 3
#define BACK 4
#define WIND 5
#define FULLS 6

extern short choice;
