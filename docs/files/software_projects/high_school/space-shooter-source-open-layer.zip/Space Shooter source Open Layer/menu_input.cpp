
#include <stdio.h>
#include "menu_functions.h"
#include "graphics.h"
#include "funct_defs.h"

void input_menu()
{
 if (key[KEY_DOWN] && choice==START && choice_delay>=20) 
 {
  choice = HELP;
  choice_delay = 0;
 }
 else if (key[KEY_DOWN] && choice==HELP && choice_delay>=20) 
 {
  choice = OPTIONS;
  choice_delay = 0;
 }
 else if (key[KEY_DOWN] && choice==OPTIONS && choice_delay>=20) 
 {
  choice = EXIT;
  choice_delay = 0;
 }
 else if (key[KEY_DOWN] && choice==EXIT && choice_delay>=20) 
 {
  choice = START;
  choice_delay = 0;
 }
 
 
 if (key[KEY_UP] && choice==START && choice_delay>=50) 
 {
  choice = EXIT;
  choice_delay = 0;
 }
 else if (key[KEY_UP] && choice==EXIT && choice_delay>=50) 
 {
  choice = OPTIONS;
  choice_delay = 0;
 }
 else if (key[KEY_UP] && choice ==OPTIONS && choice_delay>=50) 
 {
  choice = HELP;
  choice_delay = 0;
 }
 else if (key[KEY_UP] && choice ==HELP && choice_delay>=50) 
 {
  choice = START;
  choice_delay = 0;
 }
 if (key[KEY_ENTER] && choice == START) 
 {
  mode = GAME;
  frame_counter=0;
 }
 if (key[KEY_ENTER] && choice == EXIT) game_on=FALSE;
 if (key[KEY_ENTER] && choice == OPTIONS) 
 {
  menu=OPTIONS_MENU;
  choice = BACK;
  choice_delay=0;
 }
 if (key[KEY_ENTER] && choice == BACK && choice_delay>=50)
 {
  menu = MAIN_MENU;
  choice = START;
 } 
 
 if (menu == MAIN_MENU)
 {
  if (cursor_x>=295 && cursor_x<=545 && cursor_y >=380 && cursor_y <=410)
  {
   choice = START;
   if (mouse_b & 1) 
   {
    mode = GAME;
    frame_counter=0;
   }
  }
 
  if (cursor_x>=355 && cursor_x<=460 && cursor_y >=425 && cursor_y <=455)
  {
   choice = HELP;
  }
 
  if (cursor_x>=325 && cursor_x<=500 && cursor_y >=465 && cursor_y <=495)
  { 
   choice = OPTIONS;
   if (mouse_b & 1) 
   {
    menu=OPTIONS_MENU;
    choice_delay=0;
    choice = BACK;
   }  
  }  
 
  if (cursor_x>=365 && cursor_x<=455 && cursor_y >=515 && cursor_y <=545)
  {
   choice = EXIT;
   if (mouse_b & 1 && choice_delay>=50) game_on=FALSE;  
  }
 }

 else if (menu== OPTIONS_MENU)
  {
   if (cursor_x>=265 && cursor_x<=420 && cursor_y>=100 && cursor_y<=145) 
   {
    choice= WIND;
    if (mouse_b & 1 && g_mode==FULL) 
    {
     g_mode = WINDOW;
    }
   }
   
   if (cursor_x>=265 && cursor_x<=440 && cursor_y>=140 && cursor_y<=170)
   {
    choice = FULLS;
    if (mouse_b & 1 && g_mode==WINDOW ) 
    {
     g_mode=FULL;
    }
   } 
   
   if (cursor_x>=330 && cursor_x<=420 && cursor_y>=530 && cursor_y<=570)
   {
    choice = BACK;
    if (mouse_b & 1) 
    {
     menu=MAIN_MENU;
     choice = START;
     save_settings();
     choice_delay=0;
    }
   } 
}
 
 if (key[KEY_ESC] && choice_delay>=80) game_on=FALSE;
}




   
