#include "characters.h"
#include "funct_defs.h"
#include "game_units.h"

SAMPLE *shot= load_sample("sound_music/player_fire.wav");

void input_game()
{
 if (key[KEY_LEFT] && player1.loc_x > 0 && player1.state==ALIVE ){
    player1.loc_x-= player1.speed * deltaTime;
    player1.direction = LEFT;
 }
 
else if ( !key[KEY_LEFT] || !key[KEY_RIGHT]) player1.direction = STRAIGHT;   
          
 if (key[KEY_RIGHT] && player1.loc_x < 780  && player1.state==ALIVE ){
    player1.loc_x+= player1.speed * deltaTime;
    player1.direction = RIGHT;
 }
  
 if (key[KEY_UP] && player1.loc_y>0 && player1.state==ALIVE){
    player1.loc_y-= player1.speed * deltaTime;  //the y axis is flipped.  Bitmaps are read and drawn from bottom up.
 }                       //even though there origin is at the top-left.  
          
 if (key[KEY_DOWN] && player1.loc_y<550 && player1.state==ALIVE ){
    player1.loc_y+= player1.speed * deltaTime;
 }
 
 
          
 if (key[KEY_SPACE]  && player1.state==ALIVE)
    {
    if (power_level ==1)
       {
        if (player1.shot_timer>=0 && player1.shot_timer<=2)
        {
         playergun_1[0].loc_x = player1.loc_x+22;
         playergun_1[0].loc_y = player1.loc_y-5;
         play_sample(shot, vol_sound, vol_sound, 1400, 0);
        }
        else if (player1.shot_timer >= 10 && player1.shot_timer<=12)
        {
         playergun_1[1].loc_x = player1.loc_x+22;
         playergun_1[1].loc_y = player1.loc_y-5;
         play_sample(shot, vol_sound, vol_sound, 1400, 0);
        }
        else if (player1.shot_timer >= 20 && player1.shot_timer<=22)
        {
         playergun_1[2].loc_x = player1.loc_x+22;
         playergun_1[2].loc_y = player1.loc_y-5;
         play_sample(shot, vol_sound, vol_sound, 1400, 0);
        }
        else if (player1.shot_timer >= 30  && player1.shot_timer<=32)
        {
         playergun_1[3].loc_x = player1.loc_x+22;
         playergun_1[3].loc_y = player1.loc_y-5;
         play_sample(shot, vol_sound, vol_sound, 1400, 0);
        }
        else if (player1.shot_timer >= 40  && player1.shot_timer<=42)
        {
         playergun_1[4].loc_x = player1.loc_x+22;
         playergun_1[4].loc_y = player1.loc_y-5;
         play_sample(shot, vol_sound, vol_sound, 1400, 0);
        }
        else if (player1.shot_timer >= 50  && player1.shot_timer<=52)
        {
         playergun_1[5].loc_x = player1.loc_x+22;
         playergun_1[5].loc_y = player1.loc_y-5;
         play_sample(shot, vol_sound, vol_sound, 1400, 0);
        }
        else if (player1.shot_timer >= 60  && player1.shot_timer<=62)
        {
         playergun_1[6].loc_x = player1.loc_x+22;
         playergun_1[6].loc_y = player1.loc_y-5;
         play_sample(shot, vol_sound, vol_sound, 1400, 0);
        }
        else if (player1.shot_timer >= 70  && player1.shot_timer<=72)
        {
         playergun_1[7].loc_x = player1.loc_x+22;
         playergun_1[7].loc_y = player1.loc_y-5;
         play_sample(shot, vol_sound, vol_sound, 1400, 0);
        }
        else if (player1.shot_timer >= 80  && player1.shot_timer<=82)
        {
         playergun_1[8].loc_x = player1.loc_x+22;
         playergun_1[8].loc_y = player1.loc_y-5;
         play_sample(shot, vol_sound, vol_sound, 1400, 0);
        }
        else if (player1.shot_timer >= 90  && player1.shot_timer<=92)
        {
         playergun_1[9].loc_x = player1.loc_x+22;
         playergun_1[9].loc_y = player1.loc_y-5;
         play_sample(shot, vol_sound, vol_sound, 1400, 0);
        }
    }
    
    else if (power_level ==2)
    {
       if (player1.shot_timer==0)
       {
        playergun_1[0].loc_x = player1.loc_x+33;
        playergun_1[0].loc_y = player1.loc_y+10;
        
        playergun_2[0].loc_x = player1.loc_x+8;
        playergun_2[0].loc_y = player1.loc_y+10;
        play_sample(shot, vol_sound, vol_sound, 1200, 0);
       }
       else if (player1.shot_timer==10)
       {
        playergun_1[1].loc_x = player1.loc_x+33;
        playergun_1[1].loc_y = player1.loc_y+10;
        
        playergun_2[1].loc_x = player1.loc_x+8;
        playergun_2[1].loc_y = player1.loc_y+10;
        play_sample(shot, vol_sound, vol_sound, 1200, 0);
       }
       else if (player1.shot_timer==20)
       {
        playergun_1[2].loc_x = player1.loc_x+33;
        playergun_1[2].loc_y = player1.loc_y+10;
        
        playergun_2[2].loc_x = player1.loc_x+8;
        playergun_2[2].loc_y = player1.loc_y+10;
        play_sample(shot, vol_sound, vol_sound, 1200, 0);
       }
       else if (player1.shot_timer==30)
       {
        playergun_1[3].loc_x = player1.loc_x+33;
        playergun_1[3].loc_y = player1.loc_y+10;
        
        playergun_2[3].loc_x = player1.loc_x+8;
        playergun_2[3].loc_y = player1.loc_y+10;
        play_sample(shot, vol_sound, vol_sound, 1200, 0);
       }
       else if (player1.shot_timer==40)
       {
        playergun_1[4].loc_x = player1.loc_x+33;
        playergun_1[4].loc_y = player1.loc_y+10;
        
        playergun_2[4].loc_x = player1.loc_x+8;
        playergun_2[4].loc_y = player1.loc_y+10;
        play_sample(shot, vol_sound, vol_sound, 1200, 0);
       }
       else if (player1.shot_timer==50)
       {
        playergun_1[5].loc_x = player1.loc_x+33;
        playergun_1[5].loc_y = player1.loc_y+10;
        
        playergun_2[5].loc_x = player1.loc_x+8;
        playergun_2[5].loc_y = player1.loc_y+10;
        play_sample(shot, vol_sound, vol_sound, 1200, 0);
       }
       else if (player1.shot_timer==60)
       {
        playergun_1[6].loc_x = player1.loc_x+33;
        playergun_1[6].loc_y = player1.loc_y+10;
        
        playergun_2[6].loc_x = player1.loc_x+8;
        playergun_2[6].loc_y = player1.loc_y+10;
        play_sample(shot, vol_sound, vol_sound, 1200, 0);
       }
       else if (player1.shot_timer==70)
       {
        playergun_1[7].loc_x = player1.loc_x+33;
        playergun_1[7].loc_y = player1.loc_y+10;
        
        playergun_2[7].loc_x = player1.loc_x+8;
        playergun_2[7].loc_y = player1.loc_y+10;
        play_sample(shot, vol_sound, vol_sound, 1200, 0);
       }
       else if (player1.shot_timer==80)
       {
        playergun_1[8].loc_x = player1.loc_x+33;
        playergun_1[8].loc_y = player1.loc_y+10;
        
        playergun_2[8].loc_x = player1.loc_x+8;
        playergun_2[8].loc_y = player1.loc_y+10;
        play_sample(shot, vol_sound, vol_sound, 1200, 0);
       }
       else if (player1.shot_timer==90)
       {
        playergun_1[9].loc_x = player1.loc_x+33;
        playergun_1[9].loc_y = player1.loc_y+10;
        
        playergun_2[9].loc_x = player1.loc_x+8;
        playergun_2[9].loc_y = player1.loc_y+10;
        play_sample(shot, vol_sound, vol_sound, 1200, 0);
       }
    }
           
    else if (power_level ==3)
       {
        if (player1.shot_timer ==0)
        {
         playergun_1[0].loc_x = player1.loc_x+22;
         playergun_1[0].loc_y = player1.loc_y-5;
           
         playergun_2[0].loc_x = player1.loc_x+8;
         playergun_2[0].loc_y = player1.loc_y+00;
           
         playergun_3[0].loc_x = player1.loc_x+33;
         playergun_3[0].loc_y = player1.loc_y+00;
         play_sample(shot, vol_sound, vol_sound, 1000, 0);
        }
        else if (player1.shot_timer ==10)
        {
         playergun_1[1].loc_x = player1.loc_x+22;
         playergun_1[1].loc_y = player1.loc_y-5;
           
         playergun_2[1].loc_x = player1.loc_x+8;
         playergun_2[1].loc_y = player1.loc_y+10;
           
         playergun_3[1].loc_x = player1.loc_x+33;
         playergun_3[1].loc_y = player1.loc_y+10;
         play_sample(shot, vol_sound, vol_sound, 1000, 0);
        }
        else if (player1.shot_timer ==20)
        {
         playergun_1[2].loc_x = player1.loc_x+22;
         playergun_1[2].loc_y = player1.loc_y-5;
           
         playergun_2[2].loc_x = player1.loc_x+8;
         playergun_2[2].loc_y = player1.loc_y+10;
           
         playergun_3[2].loc_x = player1.loc_x+33;
         playergun_3[2].loc_y = player1.loc_y+10;
         play_sample(shot, vol_sound, vol_sound, 1000, 0);
        }
        else if (player1.shot_timer ==30)
        {
         playergun_1[3].loc_x = player1.loc_x+22;
         playergun_1[3].loc_y = player1.loc_y-5;
           
         playergun_2[3].loc_x = player1.loc_x+8;
         playergun_2[3].loc_y = player1.loc_y+10;
           
         playergun_3[3].loc_x = player1.loc_x+33;
         playergun_3[3].loc_y = player1.loc_y+10;
         play_sample(shot, vol_sound, vol_sound, 1000, 0);
        }
        else if (player1.shot_timer ==40)
        {
         playergun_1[4].loc_x = player1.loc_x+22;
         playergun_1[4].loc_y = player1.loc_y-4;
           
         playergun_2[4].loc_x = player1.loc_x+8;
         playergun_2[4].loc_y = player1.loc_y+10;
           
         playergun_3[4].loc_x = player1.loc_x+33;
         playergun_3[4].loc_y = player1.loc_y+10;
         play_sample(shot, vol_sound, vol_sound, 1000, 0);
        }
        else if (player1.shot_timer ==50)
        {
         playergun_1[5].loc_x = player1.loc_x+22;
         playergun_1[5].loc_y = player1.loc_y-5;
           
         playergun_2[5].loc_x = player1.loc_x+8;
         playergun_2[5].loc_y = player1.loc_y+10;
           
         playergun_3[5].loc_x = player1.loc_x+33;
         playergun_3[5].loc_y = player1.loc_y+10;
         play_sample(shot, vol_sound, vol_sound, 1000, 0);
        }
        else if (player1.shot_timer ==60)
        {
         playergun_1[6].loc_x = player1.loc_x+22;
         playergun_1[6].loc_y = player1.loc_y-5;
           
         playergun_2[6].loc_x = player1.loc_x+8;
         playergun_2[6].loc_y = player1.loc_y+10;
           
         playergun_3[6].loc_x = player1.loc_x+33;
         playergun_3[6].loc_y = player1.loc_y+10;
         play_sample(shot, vol_sound, vol_sound, 1000, 0);
        }
        else if (player1.shot_timer ==70)
        {
         playergun_1[7].loc_x = player1.loc_x+22;
         playergun_1[7].loc_y = player1.loc_y-5;
           
         playergun_2[7].loc_x = player1.loc_x+8;
         playergun_2[7].loc_y = player1.loc_y+10;
           
         playergun_3[7].loc_x = player1.loc_x+33;
         playergun_3[7].loc_y = player1.loc_y+10;
         play_sample(shot, vol_sound, vol_sound, 1000, 0);
        }
        else if (player1.shot_timer ==80)
        {
         playergun_1[8].loc_x = player1.loc_x+22;
         playergun_1[8].loc_y = player1.loc_y-5;
           
         playergun_2[8].loc_x = player1.loc_x+8;
         playergun_2[8].loc_y = player1.loc_y+10;
           
         playergun_3[8].loc_x = player1.loc_x+33;
         playergun_3[8].loc_y = player1.loc_y+10;
         play_sample(shot, vol_sound, vol_sound, 1000, 0);
        }
        else if (player1.shot_timer ==90)
        {
         playergun_1[9].loc_x = player1.loc_x+22;
         playergun_1[9].loc_y = player1.loc_y-5;
           
         playergun_2[9].loc_x = player1.loc_x+8;
         playergun_2[9].loc_y = player1.loc_y+10;
           
         playergun_3[9].loc_x = player1.loc_x+33;
         playergun_3[9].loc_y = player1.loc_y+10;
         play_sample(shot, vol_sound, vol_sound, 1000, 0);
        }
       clear_keybuf();
       }
    }    
}

void spec_input_game()
{
 if (lives>=0)
 {
 if (key[KEY_P]) 
 {
  if (state==RUNNING  && choice_delay>=10) 
  {
   state=PAUSED;
   choice_delay=0;
  }
  else if (state==PAUSED && choice_delay>=10) 
  {
   state=RUNNING;
   choice_delay=0;
  }
 }
 }
 
 if (key[KEY_Q]) 
 {
  starting_vars();
  mode=MENU;
 }
}


