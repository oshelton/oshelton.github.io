#ifndef game_units_h
#define game_units_h

#include <openlayer.hpp>
#include <vector>

using namespace ol;
using namespace std;

#define DEAD 0
#define ALIVE 1

#define ON 100
#define OFF 101

#define STRAIGHT 10
#define LEFT     11
#define RIGHT    12

void player1_anim();
void deinit(); //voids the deinit (clear_keybuf()) function, a bit of a waiste.
void enemy_basic_anim();
void load_wave1();
void col_check();

extern struct powerup speedinc;  
extern struct powerup healthinc;
extern struct powerup powerinc;     


extern struct projectile enemygun;
extern struct projectile enemygun_2;

extern struct character player1;

extern struct projectile playergun_1[10];
extern struct projectile playergun_2[10]; 
extern struct projectile playergun_3[10];

extern DATAFILE *graphics;

extern struct PMASK *enemybasic_mask, *bullet_mask, *enemy_bullet_mask, *player_mask, *powerup_mask;  //declares the masks used in pixel-perfect collision

extern float star_scroll;
extern float star_scroll_2;

extern int health_width;
extern int gun_width;
extern int speed_width;

extern int wave;
extern int num_small;
extern int num_med;
extern int num_large;

extern int i_rand;
extern int i_rand_2;

extern int power_level;

extern class GfxRend gfx;

#endif
