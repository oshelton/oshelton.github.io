#include <stdio.h>
#include "characters.h"
#include "game_units.h"
#include "funct_defs.h"

void load_wave1()
{
 FILE *wave_1 = NULL;
 wave_1 = fopen("data/wave1.txt", "r");
 
 fscanf (wave_1, "%s %i", &junk, &num_small);


 enemy_small.resize(num_small);

 for (i=0; i<enemy_small.size(); i++) fscanf (wave_1, "%s %f %f", &junk, &enemy_small[i].loc_x, &enemy_small[i].spawn_timer);
 
 fclose (wave_1);
}
