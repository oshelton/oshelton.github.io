#include <allegro.h>

struct character
{
       int loc_x;
       int loc_y;
       
       int speed;
       int health; 
       short state;
       int direction;
       int shield;
       
       int explode_timer;
       int shield_timer;      
};



struct powerup
{
      int loc_x;
      double loc_y;
      int spawn_timer; 
};

struct projectile
{
       float loc_x;
       float loc_y;
};     





