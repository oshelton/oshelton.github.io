#ifndef funct_def_h
#define funct_def_h
#include <OpenLayer.hpp>
#include <loadpng.h>
#include <strings.h>
#include <stdio.h>


#define pi 3.14156

#define DEAD 0
#define ALIVE 1

#define ON 100
#define OFF 101

#define MENU 2
#define GAME 3

#define MAIN_MENU 20
#define HELP_MENU 21
#define OPTIONS_MENU 22

#define WINDOW 0
#define FULL 1

#define RUNNING 0
#define PAUSED  1

using namespace ol;


//declare special global variables

extern int vol_sound;
extern int vol_music;

extern char junk[128];
extern char g_mode_string[24];
extern short game_on;
extern unsigned short mode; 
extern bool g_mode; 
extern bool state;
extern float choice_delay;
extern unsigned int menu;
extern float deltaTime;
extern float frame_counter;



extern unsigned int score;
extern int lives;

extern int cursor_x;
extern int cursor_y;

//declare trig functions and variables and initializing and timer functions
void load_settings();
void save_settings();

extern float cos_values[361];
extern float sin_values[361];

void cos_table();
void sin_table();

//declare menu functuions
void set_menu_vars();
void input_menu();
void spec_input_game();
void logic_menu();
void draw_menu();

//declare in-game functions

void starting_vars();
void input_game();
void logic_game();
void draw_game();



extern FILE *game_settings;



#endif
